# fundamental_soft.py — soft score + cache Drive
import os, time, json
from pathlib import Path
from datetime import datetime, timedelta
import yfinance as yf
import numpy as np

CACHE_DIR = Path(__file__).resolve().parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
FUND_CACHE = CACHE_DIR / "fundamentals_cache.json"

FUNDAMENTAL_MODE = "soft"  # soft | strict | off
CACHE_MAX_DAYS = 7
SLEEP_SEC = 0.35
MAX_RETRY = 3

def _safe_float(v):
    try:
        if v is None: return None
        x = float(v)
        if np.isnan(x) or np.isinf(x): return None
        return x
    except Exception:
        return None

def _load_cache():
    if not FUND_CACHE.exists(): return {}
    try:
        with open(FUND_CACHE, "r") as f: return json.load(f)
    except Exception:
        return {}

def _save_cache(cache):
    with open(FUND_CACHE, "w") as f: json.dump(cache, f)

def _is_fresh(entry):
    ts = entry.get("_ts")
    if not ts: return False
    try:
        return (datetime.now() - datetime.fromisoformat(ts)) < timedelta(days=CACHE_MAX_DAYS)
    except Exception:
        return False

def fetch_fundamental_one(ticker):
    last_err = None
    for attempt in range(MAX_RETRY):
        try:
            info = yf.Ticker(ticker).info or {}
            return {
                "trailingPE": _safe_float(info.get("trailingPE")),
                "priceToBook": _safe_float(info.get("priceToBook")),
                "earningsGrowth": _safe_float(info.get("earningsGrowth")),
                "returnOnEquity": _safe_float(info.get("returnOnEquity")),
                "debtToEquity": _safe_float(info.get("debtToEquity")),
                "pegRatio": _safe_float(info.get("pegRatio")),
                "profitMargins": _safe_float(info.get("profitMargins")),
                "operatingMargins": _safe_float(info.get("operatingMargins")),
                "_ts": datetime.now().isoformat(),
                "_ok": True,
            }
        except Exception as e:
            last_err = str(e)
            time.sleep(SLEEP_SEC * (2 ** attempt))
    return {"_ts": datetime.now().isoformat(), "_ok": False, "_err": last_err}

def get_fundamentals_batch(tickers):
    cache = _load_cache()
    out, to_fetch = {}, []
    for t in tickers:
        if t in cache and _is_fresh(cache[t]) and cache[t].get("_ok", False):
            out[t] = cache[t]
        else:
            to_fetch.append(t)
    print(f"📦 Cache hit: {len(out)} | Fetch baru: {len(to_fetch)}")
    failed = 0
    for i, t in enumerate(to_fetch, 1):
        data = fetch_fundamental_one(t)
        cache[t] = data
        out[t] = data
        if not data.get("_ok"): failed += 1
        if i % 10 == 0 or i == len(to_fetch):
            print(f"   ✓ {i}/{len(to_fetch)} (failed: {failed})")
            _save_cache(cache)
        time.sleep(SLEEP_SEC)
    _save_cache(cache)
    ok = sum(1 for v in out.values() if v.get("_ok"))
    print(f"✅ Fundamental: {ok}/{len(tickers)} OK | mode={FUNDAMENTAL_MODE}")
    return out

def fundamental_score(fund):
    if FUNDAMENTAL_MODE == "off": return 0.5
    if not fund or not fund.get("_ok", False): return 0.5
    checks = []
    pe, pb = fund.get("trailingPE"), fund.get("priceToBook")
    eg, roe = fund.get("earningsGrowth"), fund.get("returnOnEquity")
    dte, peg, pm = fund.get("debtToEquity"), fund.get("pegRatio"), fund.get("profitMargins")
    if pe is not None: checks.append(1.0 if 0 < pe < 30 else 0.0)
    if pb is not None: checks.append(1.0 if 0 < pb < 3.5 else 0.0)
    if eg is not None: checks.append(1.0 if 0.02 < eg < 5 else 0.0)
    if roe is not None: checks.append(1.0 if roe > 0.05 else 0.0)
    if dte is not None: checks.append(1.0 if dte < 100 else 0.0)
    if peg is not None: checks.append(1.0 if 0 < peg < 1.5 else 0.0)
    if pm is not None: checks.append(1.0 if pm > 0.05 else 0.0)
    return float(np.mean(checks)) if checks else 0.5

def is_fundamentally_attractive(fund):
    if FUNDAMENTAL_MODE == "off": return True
    sc = fundamental_score(fund)
    if FUNDAMENTAL_MODE == "soft":
        return sc >= 0.40   # kosong = 0.5 → True (tidak memblokir)
    if not fund or not fund.get("_ok", False): return False
    return sc >= 0.50

def get_fundamental_data(ticker):
    """Kompatibel API lama."""
    return get_fundamentals_batch([ticker]).get(ticker, {})
