# ============================================================
#  Codex Rev 37.5.2 – SHARPE FIX (P1:threshold + P2:TC per-sisi + P3:ATR longgar)
#  SHM Aladdin Clone · IDX Full Universe · MULTI-FACTOR SIGNAL
#  DENGAN ENHANCED ENTRY/EXIT + ADAPTIVE MARKET REGIME
#  + COMPOSITE SIGNAL SCORE + HYBRID SELECTION LOGIC
#
#  CHANGELOG vs 37.3.1:
#  [2a] ROC_3 gantikan MACD — lebih responsif untuk 1-hari holding
#  [2b] Gap_Overnight — minat beli di pembukaan dari gap Close→Open
#  [2d] Vol_ROC_3 — akselerasi volume 3 hari vs MA20 (bukan binary)
#  [2e] Regime detection dual: return_5d + return_20d, konflik→NORMAL
#  [3d] HL_Spread_Filter — proxy bid-ask dari (High-Low)/Close >5% = eksklusi
#  [3e] Sector_RS — relative strength sektoral vs IDX universe
#
#  CARRY FORWARD dari 37.3.1:
#  [FT-1~7] Fine-tuning weights, RSI asimetris, momentum vol-norm, dll
#  [CF-1,2] P&D 250%, MC mid_val=median unrealized
#  [1a,1b,1d] Quality Gate: MIN_SHARPE, MIN_WINRATE, MIN_BACKTEST_TRADES
#  [3a,3b,3c] price_open, candle pattern, RS vs IHSG
# ============================================================

import subprocess
import sys
import importlib
import time
import warnings
warnings.filterwarnings("ignore")

# =============================================================
# Install packages jika di Colab  [BUG 1 FIX]
# Import heavy packages SETELAH install selesai agar tidak
# ImportError di fresh Colab environment
# =============================================================
def install_package(pkg):
    import_name_map = {
        "yfinance": "yfinance",
        "pandas": "pandas",
        "numpy": "numpy",
        "matplotlib": "matplotlib",
        "scipy": "scipy",
        "arch": "arch",
    }
    import_name = import_name_map.get(pkg, pkg)
    try:
        importlib.import_module(import_name)
        print(f"   ✓ {pkg} already installed")
    except ImportError:
        print(f"   Installing {pkg}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pkg])

print("Checking required packages...")
for p in ["yfinance", "pandas", "numpy", "matplotlib", "scipy", "arch"]:
    install_package(p)

# Import setelah install selesai
import yfinance as yf

# === TAHAP2: soft fundamental ===
try:
    from fundamental_soft import (
        get_fundamentals_batch, get_fundamental_data,
        is_fundamentally_attractive, fundamental_score, FUNDAMENTAL_MODE,
    )
    print(f"   ✓ fundamental_soft loaded (mode={FUNDAMENTAL_MODE})")
except Exception as _e:
    print(f"   ⚠️ fundamental_soft gagal import: {_e}")
# === END TAHAP2 ===
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

# Import scipy dan arch
try:
    from scipy.stats import qmc, t as _scipy_t
    QMC_AVAILABLE = True
except ImportError:
    QMC_AVAILABLE = False
    _scipy_t = None
    print("⚠️ scipy.stats.qmc atau t tidak tersedia")

try:
    from arch import arch_model
    ARCH_AVAILABLE = True
    print("   ✓ arch package available")
except ImportError:
    ARCH_AVAILABLE = False
    print("⚠️ arch package tidak tersedia")

# Setup matplotlib
try:
    plt.style.use("default")
    plt.rcParams["figure.figsize"] = [12, 6]
    plt.rcParams["font.family"] = "DejaVu Sans"
except Exception:
    pass

# =============================================================
# 1. HYBRID CONFIG 37.1.5 - BEST OF BOTH WORLDS
# =============================================================
INITIAL_CAPITAL  = 100_000_000
RISK_PER_TRADE   = 0.01
TRANSACTION_COST = 0.003
RF_DAILY         = 0.0475 / 252
BATCH_SIZE       = 30

USE_MACRO_FILTER = True   # [2c] Aktif: oil + IDR filter berlaku
OIL_THRESHOLD    = -3.0

SELECTION_MODE = "HYBRID"

# =============== HYBRID CONFIGURATION ===============
USE_ADAPTIVE_REGIME = True
INTRADAY_MODE = True
MAX_HOLDING_DAYS = 3
INTRADAY_EXIT_HOUR = 15
EXIT_PROFIT_HOUR = 14.5
ADAPTIVE_VERBOSE = False

# Composite Signal Score Weights
# [37.4.0] 10 faktor, total = 1.00
# [2a] ROC_3 menggantikan MACD, masuk ke komponen "momentum"
# [2b] gap_overnight — minat beli pembukaan dari gap Close->Open
# [2d] vol_roc — akselerasi volume 3 hari vs MA20
# [3e] sector_rs — relative strength sektoral
# [SIGNAL_ENTRY_PATCH] BUY+volume, SELL longgar
COMPOSITE_WEIGHTS = {
    "trend":         0.22,  # MA structure — fondasi tren
    "volume":        0.16,  # Volume_Confirmation binary
    "rsi":           0.10,  # RSI asimetris per regime
    "momentum":      0.18,  # ROC_3 [2a] — lebih responsif dari MACD
    "low_vol":       0.03,  # tie-breaker minimal
    "candle":        0.08,  # [3b] candle pattern kemarin
    "rs_ihsg":       0.08,  # [3c] relative strength vs IHSG
    "gap_overnight": 0.07,  # [2b] BARU — gap Close->Open
    "vol_roc":       0.05,  # [2d] BARU — akselerasi volume 3 hari
    "sector_rs":     0.03,  # [3e] BARU — relative strength sektoral
    # Total = 0.22+0.16+0.10+0.18+0.03+0.08+0.08+0.07+0.05+0.03 = 1.00
}

# Threshold yang lebih balanced
THRESHOLD = {
    "HIGH_VOL": 0.60,
    "BULLISH": 0.55,
    "NORMAL": 0.55,
    "BEARISH": 0.60,
    "SIDEWAYS": 0.58,
}

# Enhanced Backtest Parameters
ATR_TRAILING_MULTIPLIER = 1.8    # [FIX-P3] ↑ dari 1.5 → memberi ruang nafas volatilitas pembukaan IDX
MAX_SL_DISTANCE_PCT = 0.050      # [FIX-P3] ↑ dari 0.035 (3.5%→5.0%) → mengurangi premature stop-out saham lapis 2-3
VOLUME_RATIO_THRESHOLD = 1.4
VOLUME_DIVERGENCE_THRESHOLD = 0.5
MIN_PROFIT_FOR_TIME_EXIT = 0.008

# =============== FORECAST ENGINE ===============
T_DIST_DF = 5
MOMENTUM_ADJ_FACTOR = 0.0002
USE_GARCH_VOL = True
GARCH_P = 1
GARCH_Q = 1

# =============== VOLATILITY-BASED EXIT ===============
VOL_SPIKE_MULTIPLIER = 2.0

# =============== VOLATILITY SCALING ===============
TARGET_VOL_DAILY  = 0.02
MAX_POSITION_SIZE = 0.08
DEFAULT_RISK_SIZE = RISK_PER_TRADE

# =============== SHARPE-BASED POSITION SCALING ===============
SHARPE_HIGH_THRESH = 1.0
SHARPE_LOW_THRESH  = 0.5
SHARPE_SCALE_UP    = 1.5
SHARPE_SCALE_DOWN  = 0.5

# =============== MONTE CARLO GATEKEEPER CONFIG ===============
N_SIMULATIONS = 2500
# [MC-OPT] Dinaikkan dari 1000→2500.
# Analisis statistik: di zona borderline P_SL 35-45%, SE turun dari ±2.2% ke ±1.4%.
# Perbedaan ini cukup untuk mengurangi misklasifikasi STRONG BUY vs BUY.
# Waktu eksekusi: +0.002 detik per saham → tidak terasa untuk 10 saham output.
HORIZON       = 1
DF_STUDENT    = 5
P_SL_STRONG   = 0.40
P_SL_WATCH    = 0.60

# =============== QUALITY GATE — HARD FILTER BARU (Fase 1) ===============
# [1a] Minimum Sharpe backtest — saham dengan Sharpe lebih buruk dari ini dibuang
# -1.5 artinya: boleh rugi tipis, tapi tidak boleh rugi parah secara konsisten
MIN_SHARPE         = -3.0

# [1b] Minimum Win Rate backtest — saham yang menang < 25% trade historis dibuang
# Analogi: jockey yang menang 1 dari 4 lomba masih layak; yang menang 1 dari 20 tidak
MIN_WINRATE        = 10.0   # dalam persen

# [1d] Minimum jumlah trade di backtest — saham yang tidak pernah dimasuki dibuang
# Trades=0 artinya sinyal tidak pernah terpenuhi, tidak ada data backtest valid
# [P1] Diturunkan dari 5→3: trades=3 masih punya minimal data backtest bermakna,
#      dan membantu IDX1 (443 saham) yang quality gate-nya terlalu ketat.
MIN_BACKTEST_TRADES = 1

# =============== ABSOLUTE QUALITY FLOOR (tidak bisa di-bypass Relax) ===============
ABS_MIN_BACKTEST_TRADES = 3
ABS_MIN_WINRATE         = 25.0   # persen
ABS_MIN_SHARPE          = -1.5

# =============== TIERED QUALITY GATE [TQG] ===================================
# Sistem bertingkat menggantikan hard filter tunggal.
# Tier 1 → kandidat terbaik, tidak ada penalti
# Tier 2 → fallback, skor dikurangi TIER2_PENALTY
# Tier 3 → last resort, skor dikurangi TIER3_PENALTY
#
# Setiap saham diberi label tier yang dibawa ke Phase 4 scoring.
# Tidak ada saham yang dibuang selama ada yang masuk tier apapun.

TQG_T1_SHARPE  =  -0.5    # Tier 1 Premium: Sharpe ≥ 0.5
TQG_T1_WINRATE = 30.0    # Tier 1 Premium: WinRate ≥ 50%
TQG_T2_SHARPE  =  -2.0    # Tier 2 Good: Sharpe ≥ 0.0
TQG_T2_WINRATE = 12.0    # Tier 2 Good: WinRate ≥ 40%
TIER1_BONUS    = +0.08   # bonus Phase 4 untuk Tier 1 (Premium)
TIER2_PENALTY  = -0.04   # penalti Phase 4 untuk Tier 2 (Good)
TIER3_PENALTY  = -0.10   # penalti Phase 4 untuk Tier 3 (Acceptable)
TQG_MIN_T1T2   =  4      # T1+T2 minimum; jika < ini, Tier 3 diizinkan masuk

# =============== DETECT_DAILY_UPTREND — MODE OPERASI =========================
# "conservative" → minimal 4/5 kondisi terpenuhi (Sharpe-adjusted)
# "balanced"     → minimal 3/5 dengan weighted score ≥ 0.65 (REKOMENDASI)
# "aggressive"   → minimal 2/5 dengan weighted score ≥ 0.45
UPTREND_MODE = "balanced"   # ganti ke "conservative" atau "aggressive" sesuai kebutuhan

# =============================================================
# Banner
# =============================================================
print("=" * 78)
print("  SHM Aladdin Clone · IDX Full Universe · Rev 37.5.2 (TQG+UTD+USDIDR+SHARPE-FIX)")
print("  HYBRID BALANCED + ROC3 + GAP + VOL_ROC + DUAL REGIME + HL_SPREAD + SECTOR_RS")
print("  Enhanced Entry/Exit + Adaptive Market Regime + Composite Signal Score")
print("  DENGAN MONTE CARLO GATEKEEPER (Student-t, df=5)")
print("=" * 78)
print(f"  Update: {datetime.now().strftime('%d %B %Y  %H:%M:%S')}\n")

print("=" * 78)
print("  ⚙️ HYBRID CONFIGURATION 37.1.5:")
print(f"     ATR_TRAILING_MULTIPLIER    : {ATR_TRAILING_MULTIPLIER}")
print(f"     EXIT_PROFIT_HOUR           : {int(EXIT_PROFIT_HOUR)}:{int((EXIT_PROFIT_HOUR % 1)*60):02d} WIB")
print(f"     MAX_SL_DISTANCE_PCT        : {MAX_SL_DISTANCE_PCT*100:.1f}%")
print(f"     VOLUME_RATIO_THRESHOLD     : {VOLUME_RATIO_THRESHOLD}x MA20")
print(f"     THRESHOLD_NORMAL           : {THRESHOLD['NORMAL']}")
print(f"     THRESHOLD_HIGH_VOL         : {THRESHOLD['HIGH_VOL']}")
print(f"     THRESHOLD_BULLISH          : {THRESHOLD['BULLISH']}")
print("=" * 78 + "\n")

if INTRADAY_MODE:
    print("=" * 78)
    print("  🕐 INTRADAY_MODE aktif")
    print(f"     EXIT_HOUR    : {INTRADAY_EXIT_HOUR}:00 WIB")
    print(f"     MAX_HOLDING  : {MAX_HOLDING_DAYS} hari")
    print("=" * 78 + "\n")

# =============================================================
# Helper functions
# =============================================================
def fmt(val, spec=".2f"):
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "N/A"
    if isinstance(val, str):
        return val
    try:
        return format(float(val), spec)
    except (ValueError, TypeError):
        return "N/A"

def normalize(series):
    if series.empty or series.nunique() == 0:
        return pd.Series([0.5] * len(series), index=series.index)
    if series.nunique() == 1:
        return pd.Series([0.5] * len(series), index=series.index)
    return (series - series.min()) / (series.max() - series.min())

def calc_sharpe(daily_returns, rf=RF_DAILY):
    r = pd.Series(daily_returns).dropna()
    if len(r) < 10 or r.std() == 0 or pd.isna(r.std()):
        return np.nan
    excess = r - rf
    return float((excess.mean() / r.std()) * np.sqrt(252))

# =============================================================
# MARKET REGIME DETECTION
# =============================================================
# ── [3e] SEKTOR IDX — mapping ticker ke 11 sektor resmi BEI ─────────────────
# Digunakan untuk menghitung Sector_RS (relative strength sektoral).
# Saham yang sektornya sedang outperform IHSG lebih mungkin lanjut naik.
IDX_SECTOR_MAP = {
    # ENERGI
    "ADRO.JK":"ENERGY","PTBA.JK":"ENERGY","ITMG.JK":"ENERGY","BYAN.JK":"ENERGY",
    "DEWA.JK":"ENERGY","HRUM.JK":"ENERGY","KKGI.JK":"ENERGY","MBSS.JK":"ENERGY",
    "MYOH.JK":"ENERGY","PKPK.JK":"ENERGY","SMMT.JK":"ENERGY","TOBA.JK":"ENERGY",
    "APEX.JK":"ENERGY","ARTI.JK":"ENERGY","BIPI.JK":"ENERGY","ELSA.JK":"ENERGY",
    "ENRG.JK":"ENERGY","ESSA.JK":"ENERGY","MEDC.JK":"ENERGY","RUIS.JK":"ENERGY",
    # BASIC MATERIALS
    "TPIA.JK":"BASIC_MAT","BRPT.JK":"BASIC_MAT","MDKA.JK":"BASIC_MAT",
    "ANTM.JK":"BASIC_MAT","INCO.JK":"BASIC_MAT","TINS.JK":"BASIC_MAT",
    "SMGR.JK":"BASIC_MAT","INTP.JK":"BASIC_MAT","SMBR.JK":"BASIC_MAT",
    "AMFG.JK":"BASIC_MAT","ARNA.JK":"BASIC_MAT","ETWA.JK":"BASIC_MAT",
    "BAJA.JK":"BASIC_MAT","GDST.JK":"BASIC_MAT","ISSP.JK":"BASIC_MAT",
    "NIKL.JK":"BASIC_MAT","PICO.JK":"BASIC_MAT","LION.JK":"BASIC_MAT",
    # INDUSTRIALS
    "ASII.JK":"INDUSTRIAL","SRIL.JK":"INDUSTRIAL","MYOR.JK":"INDUSTRIAL",
    "GGRM.JK":"INDUSTRIAL","HMSP.JK":"INDUSTRIAL","INDF.JK":"INDUSTRIAL",
    "ICBP.JK":"INDUSTRIAL","SMCB.JK":"INDUSTRIAL","BUDI.JK":"INDUSTRIAL",
    "FASW.JK":"INDUSTRIAL","INKP.JK":"INDUSTRIAL","TKIM.JK":"INDUSTRIAL",
    "KBLI.JK":"INDUSTRIAL","SCCO.JK":"INDUSTRIAL","VOKS.JK":"INDUSTRIAL",
    # CONSUMER DISCRETIONARY
    "ACES.JK":"CONS_DISC","MAPI.JK":"CONS_DISC","LPPF.JK":"CONS_DISC",
    "RALS.JK":"CONS_DISC","ERAA.JK":"CONS_DISC","MIDI.JK":"CONS_DISC",
    "MPPA.JK":"CONS_DISC","HERO.JK":"CONS_DISC","AMRT.JK":"CONS_DISC",
    "CSAP.JK":"CONS_DISC","KINO.JK":"CONS_DISC","TCID.JK":"CONS_DISC",
    # CONSUMER STAPLES
    "UNVR.JK":"CONS_STAP","SIDO.JK":"CONS_STAP","DLTA.JK":"CONS_STAP",
    "MLBI.JK":"CONS_STAP","ULTJ.JK":"CONS_STAP","CLEO.JK":"CONS_STAP",
    "GOOD.JK":"CONS_STAP","HOKI.JK":"CONS_STAP","CAMP.JK":"CONS_STAP",
    # HEALTH CARE
    "KLBF.JK":"HEALTH","SIDO.JK":"HEALTH","KAEF.JK":"HEALTH","DVLA.JK":"HEALTH",
    "INAF.JK":"HEALTH","MIKA.JK":"HEALTH","SILO.JK":"HEALTH","HEAL.JK":"HEALTH",
    "MERK.JK":"HEALTH","PYFA.JK":"HEALTH","TSPC.JK":"HEALTH","SCPI.JK":"HEALTH",
    # FINANCIALS
    "BBCA.JK":"FINANCE","BBRI.JK":"FINANCE","BMRI.JK":"FINANCE","BBNI.JK":"FINANCE",
    "BRIS.JK":"FINANCE","BTPS.JK":"FINANCE","BDMN.JK":"FINANCE","BJBR.JK":"FINANCE",
    "BJTM.JK":"FINANCE","BNGA.JK":"FINANCE","BNII.JK":"FINANCE","PNBN.JK":"FINANCE",
    "BBTN.JK":"FINANCE","MEGA.JK":"FINANCE","NISP.JK":"FINANCE","BSDE.JK":"FINANCE",
    "ADMF.JK":"FINANCE","BFIN.JK":"FINANCE","MFIN.JK":"FINANCE","VRNA.JK":"FINANCE",
    # PROPERTY & REAL ESTATE
    "BSDE.JK":"PROPERTY","SMRA.JK":"PROPERTY","LPKR.JK":"PROPERTY","CTRA.JK":"PROPERTY",
    "PWON.JK":"PROPERTY","DILD.JK":"PROPERTY","ASRI.JK":"PROPERTY","MTLA.JK":"PROPERTY",
    "JRPT.JK":"PROPERTY","PLIN.JK":"PROPERTY","BEST.JK":"PROPERTY","BIPP.JK":"PROPERTY",
    # TECHNOLOGY
    "TLKM.JK":"TECH","EXCL.JK":"TECH","ISAT.JK":"TECH","TBIG.JK":"TECH",
    "TOWR.JK":"TECH","BREN.JK":"TECH","GOTO.JK":"TECH","BUKA.JK":"TECH",
    "WIFI.JK":"TECH","DATA.JK":"TECH","DMMX.JK":"TECH","EDGE.JK":"TECH",
    # INFRASTRUCTURE
    "JSMR.JK":"INFRA","WIKA.JK":"INFRA","PTPP.JK":"INFRA","WSKT.JK":"INFRA",
    "ADHI.JK":"INFRA","NRCA.JK":"INFRA","TOTL.JK":"INFRA","ACST.JK":"INFRA",
    "PGAS.JK":"INFRA","KIJA.JK":"INFRA","BIRD.JK":"INFRA","GIAA.JK":"INFRA",
    # TRANSPORTATION & LOGISTICS
    "SAFE.JK":"TRANSPORT","SMDR.JK":"TRANSPORT","TMAS.JK":"TRANSPORT",
    "WINS.JK":"TRANSPORT","IPCC.JK":"TRANSPORT","NELY.JK":"TRANSPORT",
}

def get_sector(ticker):
    """Return sektor IDX untuk ticker, default 'OTHER' jika tidak ditemukan."""
    return IDX_SECTOR_MAP.get(ticker, "OTHER")

# Sector_RS dihitung setelah semua backtest selesai (Phase 1).
# Disimpan sebagai dict: {sektor: rs_score 0-1}
sector_rs_scores = {}  # akan diisi setelah backtest batch selesai
# ─────────────────────────────────────────────────────────────────────────────

def detect_daily_uptrend(df, mode=None):
    """
    Deteksi konfluensi uptrend harian untuk holding period 1 hari.
    Menggunakan weighted scoring (bukan strict AND) agar tidak terlalu ketat.

    Mengembalikan dict:
      uptrend_score  : float 0.0–1.0 (weighted score dari 5 kondisi)
      uptrend_flag   : bool (True jika lolos threshold sesuai mode)
      uptrend_bonus  : float 0.0–0.09 (bonus siap dipakai di Phase 4)
      conditions_met : int  jumlah kondisi individual yang terpenuhi
      detail         : dict breakdown per kondisi

    FILOSOFI THRESHOLD (mengapa angka ini dipilih):
    ─────────────────────────────────────────────
    MA5 > MA20   : sinyal tren jangka pendek paling andal untuk 1-hari.
                   Bobot tertinggi (0.30) karena paling predictive.

    RS_Score > 0.55 : RS=0.5 berarti sama dengan IHSG. Di atas 0.55 sudah
                   outperform marginal. Threshold rendah agar tidak terlalu
                   ketat — yang penting saham lebih kuat dari market.
                   Bobot 0.25 — penting tapi lebih volatile dari MA.

    Vol_Ratio > 1.1 : Volume 10% di atas MA20 sudah cukup sebagai konfirmasi.
                   Tidak perlu 1.4x karena vol_ratio 1.4x sudah di composite.
                   Double counting dihindari dengan threshold berbeda.
                   Bobot 0.20.

    ROC_3 > 0.003  : Return 0.3% dalam 3 hari = momentum tipis tapi positif.
                   Threshold sangat rendah agar tidak over-filter saham yang
                   sideways tetapi akan breakout. Bobot 0.15.

    ATR/Close < 0.035 : Volatilitas < 3.5% dari harga = range wajar intraday.
                   Saham dengan ATR/Close > 5% terlalu berisiko untuk 1-hari.
                   Ini BUKAN duplikat HL_Spread (HL_Spread = spread intraday,
                   ATR = volatilitas rata-rata 14 hari). Bobot 0.10.

    ANTI DOUBLE COUNTING vs Composite Signal Score:
    ─────────────────────────────────────────────
    Composite Signal Score sudah punya: trend(MA), volume(binary), RSI,
    momentum(ROC_3+ROC_5), candle, RS_IHSG, gap_overnight, vol_roc, sector_rs.

    detect_daily_uptrend BERBEDA karena:
    - Menggunakan threshold berbeda (MA5>MA20 sebagai binary, bukan Trend_Strength)
    - RS_Score threshold 0.55 vs RS masuk composite sebagai continuous score
    - Vol_Ratio 1.1x vs Volume_Confirmation 1.4x di composite
    - ROC_3 threshold 0.003 vs ROC_3_Score normalized di composite
    - ATR/Close belum ada sama sekali di composite score

    Hasil uptrend_bonus ditambahkan ke Phase 4 Score SETELAH normalisasi,
    sehingga tidak mempengaruhi bobot antar faktor di composite signal.
    """
    _mode = mode or UPTREND_MODE

    # Threshold per mode
    THRESHOLDS = {
        "conservative": {
            "vol_ratio": 1.3,   # volume lebih kuat dari rata-rata
            "rs_score":  0.60,  # outperform IHSG lebih jelas
            "roc3":      0.005, # momentum lebih nyata
            "atr_pct":   0.030, # volatilitas lebih terkontrol
            "min_score": 0.75,  # weighted score minimal
            "bonus":     0.09,  # bonus Phase 4 tertinggi
        },
        "balanced": {
            "vol_ratio": 1.1,
            "rs_score":  0.55,
            "roc3":      0.003,
            "atr_pct":   0.035,
            "min_score": 0.65,
            "bonus":     0.07,
        },
        "aggressive": {
            "vol_ratio": 0.9,   # bahkan volume sedikit di bawah rata-rata OK
            "rs_score":  0.48,  # hampir setara IHSG sudah cukup
            "roc3":      0.001, # momentum sangat kecil
            "atr_pct":   0.045, # toleransi volatilitas lebih tinggi
            "min_score": 0.45,
            "bonus":     0.05,
        },
    }
    t = THRESHOLDS.get(_mode, THRESHOLDS["balanced"])

    try:
        last = df.iloc[-1]

        # ── Kondisi 1: MA5 > MA20 (bobot 0.30) ──────────────────────────────
        # Tren jangka pendek positif — paling andal untuk prediksi 1 hari
        ma5   = last.get("MA5",  np.nan)
        ma20  = last.get("MA20", np.nan)
        c1_ok = bool(pd.notna(ma5) and pd.notna(ma20) and ma5 > ma20)
        c1_w  = 0.30

        # ── Kondisi 2: RS_Score > threshold (bobot 0.25) ────────────────────
        # Saham lebih kuat dari IHSG — konteks relatif pasar
        rs = last.get("RS_Score", 0.5)
        c2_ok = bool(pd.notna(rs) and rs > t["rs_score"])
        c2_w  = 0.25

        # ── Kondisi 3: Volume Ratio > threshold (bobot 0.20) ────────────────
        # Konfirmasi minat pasar — beda dari composite (1.4x) untuk hindari duplikat
        vol    = last.get("Volume", np.nan)
        vol_ma = df["Volume"].rolling(20).mean().iloc[-1]
        vol_ratio = float(vol / vol_ma) if pd.notna(vol) and vol_ma > 0 else 1.0
        c3_ok = bool(vol_ratio > t["vol_ratio"])
        c3_w  = 0.20

        # ── Kondisi 4: ROC_3 > threshold (bobot 0.15) ───────────────────────
        # Momentum 3 hari positif — forward-looking untuk 1-hari holding
        roc3 = last.get("ROC_3", np.nan)
        c4_ok = bool(pd.notna(roc3) and roc3 > t["roc3"])
        c4_w  = 0.15

        # ── Kondisi 5: ATR/Close < threshold (bobot 0.10) ───────────────────
        # Volatilitas terkontrol — saham tidak sedang dalam fase ekstrem
        atr   = last.get("ATR", np.nan)
        close = last.get("Close", np.nan)
        atr_pct = float(atr / close) if pd.notna(atr) and pd.notna(close) and close > 0 else 0.02
        c5_ok = bool(atr_pct < t["atr_pct"])
        c5_w  = 0.10

        # ── Weighted Score ───────────────────────────────────────────────────
        weighted = (c1_ok * c1_w + c2_ok * c2_w + c3_ok * c3_w +
                    c4_ok * c4_w + c5_ok * c5_w)
        n_met    = sum([c1_ok, c2_ok, c3_ok, c4_ok, c5_ok])
        flag     = bool(weighted >= t["min_score"])
        bonus    = float(t["bonus"]) if flag else 0.0

        return {
            "uptrend_score":  round(weighted, 4),
            "uptrend_flag":   flag,
            "uptrend_bonus":  bonus,
            "conditions_met": n_met,
            "detail": {
                "ma5_gt_ma20":   c1_ok,
                "rs_score":      round(float(rs),       4),
                "vol_ratio":     round(vol_ratio,        2),
                "roc3":          round(float(roc3) if pd.notna(roc3) else 0, 5),
                "atr_pct":       round(atr_pct,          4),
            },
        }
    except Exception:
        return {"uptrend_score": 0.0, "uptrend_flag": False,
                "uptrend_bonus": 0.0, "conditions_met": 0, "detail": {}}


# TIERED QUALITY GATE INTEGRATION
def assign_quality_tier(sharpe, winrate, trades):
    """
    Tiered Quality Gate [TQG] — Rev 37.1.14 spec.
    Mengembalikan (tier: int, adjustment: float, label: str)

    Tier 1 (Premium)    : Sharpe ≥ 0.5 AND WinRate ≥ 50% → BONUS  +0.08
    Tier 2 (Good)       : Sharpe ≥ 0.0 AND WinRate ≥ 40% → penalti -0.04
    Tier 3 (Acceptable) : semua lainnya                   → penalti -0.10
                          (hanya masuk jika T1+T2 < TQG_MIN_T1T2)

    Adjustment diterapkan ke Phase 4 Score SETELAH normalisasi.
    Tier 1 mendapat BONUS sehingga aktif naik ranking, bukan hanya tidak dihukum.
    Tier 3 dikontrol masuknya via logika di select_stocks_balanced.
    """
    try:
        sh = float(sharpe)  if pd.notna(sharpe)  else -999.0
        wr = float(winrate) if pd.notna(winrate) else 0.0
    except Exception:
        return (3, TIER3_PENALTY, "T3")

    # Tier 1: Premium — Sharpe ≥ 0.5 AND WinRate ≥ 50%
    if sh >= TQG_T1_SHARPE and wr >= TQG_T1_WINRATE:
        return (1, TIER1_BONUS,   "T1★")
    # Tier 2: Good — Sharpe ≥ 0.0 AND WinRate ≥ 40%
    elif sh >= TQG_T2_SHARPE and wr >= TQG_T2_WINRATE:
        return (2, TIER2_PENALTY, "T2")
    # Tier 3: Acceptable — semua lainnya
    else:
        return (3, TIER3_PENALTY, "T3")


def get_market_regime(df, ticker=""):
    # [2e] Dual return input: return_5d (cepat) + return_20d (lambat).
    # Jika keduanya konflik arah → regime NORMAL (konservatif).
    # Analoginya: jika laporan cuaca minggu ini bilang panas tapi 3 hari ini hujan,
    # jangan pasang taruhan — tunggu sampai keduanya sepakat.
    try:
        vol_20      = df["vol_20"].iloc[-1]      if "vol_20"      in df.columns and len(df) > 0 else None
        vol_100_avg = df["vol_100_avg"].iloc[-1] if "vol_100_avg" in df.columns and len(df) > 0 else None

        current_close = df["Close"].iloc[-1]

        # Return 20 hari (regime jangka menengah)
        close_20d_ago = df["Close"].iloc[-20] if len(df) >= 20 else None
        return_20d = (current_close - close_20d_ago) / close_20d_ago \
                     if close_20d_ago and close_20d_ago > 0 else 0.0

        # [2e] Return 5 hari (regime jangka pendek — lebih relevan untuk intraday)
        close_5d_ago = df["Close"].iloc[-5] if len(df) >= 5 else None
        return_5d = (current_close - close_5d_ago) / close_5d_ago \
                    if close_5d_ago and close_5d_ago > 0 else 0.0

        # Prioritas 1: volatilitas tinggi (override semua)
        if vol_20 is not None and vol_100_avg is not None and vol_100_avg > 0:
            if vol_20 / vol_100_avg > 1.4:
                return "HIGH_VOL"

        # Tentukan arah per timeframe
        dir_20d = "up"   if return_20d >  0.04 else ("down" if return_20d < -0.03 else "flat")
        dir_5d  = "up"   if return_5d  >  0.02 else ("down" if return_5d  < -0.02 else "flat")

        # [2e] Deteksi konflik: 20d bilang bullish tapi 5d bearish (atau sebaliknya)
        conflict = (dir_20d == "up"   and dir_5d == "down") or \
                   (dir_20d == "down" and dir_5d == "up")
        if conflict:
            return "NORMAL"  # konservatif saat sinyal bertentangan

        # Tidak ada konflik → gunakan sinyal 20d (lebih stabil)
        if dir_20d == "up":
            return "BULLISH"
        elif dir_20d == "down":
            return "BEARISH"
        elif abs(return_20d) <= 0.03:
            return "SIDEWAYS"

        return "NORMAL"
    except Exception:
        return "NORMAL"

def get_adaptive_parameters(regime):
    if regime == "HIGH_VOL":
        return {
            "trend_strength_threshold": 2.8, "rsi_min": 48, "rsi_max": 68,
            "volume_ratio_threshold": 1.8, "momentum_threshold": 0.008,
            "max_position_size": 0.06, "signal_threshold": THRESHOLD["HIGH_VOL"],
            "atr_trailing_multiplier": 1.3, "min_profit_for_time_exit": 0.003,
            "volume_ratio_threshold_entry": 1.8, "allow_entry": True,
            "description": "Konservatif - Volatilitas Tinggi"
        }
    elif regime == "BULLISH":
        return {
            "trend_strength_threshold": 2.2, "rsi_min": 42, "rsi_max": 78,
            "volume_ratio_threshold": 1.3, "momentum_threshold": 0.004,
            "max_position_size": 0.12, "signal_threshold": THRESHOLD["BULLISH"],
            "atr_trailing_multiplier": 1.8, "min_profit_for_time_exit": 0.0008,
            "volume_ratio_threshold_entry": 1.3, "allow_entry": True,
            "description": "Agresif - Trend Bullish"
        }
    elif regime == "BEARISH":
        return {
            "trend_strength_threshold": 3.0, "rsi_min": 40, "rsi_max": 65,
            "volume_ratio_threshold": 1.6, "momentum_threshold": 0.010,
            "max_position_size": 0.04, "signal_threshold": THRESHOLD["BEARISH"],
            "atr_trailing_multiplier": 1.2, "min_profit_for_time_exit": 0.005,
            "volume_ratio_threshold_entry": 1.6, "allow_entry": False,
            "description": "Defensif - Pasar Menurun"
        }
    elif regime == "SIDEWAYS":
        return {
            "trend_strength_threshold": 2.3, "rsi_min": 45, "rsi_max": 70,
            "volume_ratio_threshold": 1.4, "momentum_threshold": 0.005,
            "max_position_size": 0.07, "signal_threshold": THRESHOLD["SIDEWAYS"],
            "atr_trailing_multiplier": 1.4, "min_profit_for_time_exit": 0.002,
            "volume_ratio_threshold_entry": 1.4, "allow_entry": True,
            "description": "Moderat - Pasar Rata"
        }
    else:
        return {
            "trend_strength_threshold": 2.5, "rsi_min": 45, "rsi_max": 75,
            "volume_ratio_threshold": 1.5, "momentum_threshold": 0.006,
            "max_position_size": 0.08, "signal_threshold": THRESHOLD["NORMAL"],
            "atr_trailing_multiplier": 1.5, "min_profit_for_time_exit": 0.0015,
            "volume_ratio_threshold_entry": 1.5, "allow_entry": True,
            "description": "Balanced - Pasar Normal"
        }

# =============================================================
# PUMP-AND-DUMP DETECTION
# =============================================================
def detect_pump_and_dump(df_work, backtest_results):
    # [FT-6 FIX] Threshold dikembalikan ke 250% (bukan 150%).
    # Bukti empiris dari output: threshold 150% memflag 241/458 saham (53%)
    # padahal versi 37.1.5 hanya 2/24 (8%). Banyak saham IDX naik organik
    # 100-200% dalam setahun (sektor komoditas, recovery pasca-crash).
    # 250% adalah level yang hanya ditandai oleh kenaikan ekstrem/manipulatif.
    #
    # Volume spike tetap digunakan sebagai KONFIRMASI TAMBAHAN:
    # saham baru kena flag volume-spike jika JUGA memenuhi syarat harga abnormal.
    # Bukan sebagai syarat mandiri yang bisa memflag saham aktif secara wajar.
    PND_RETURN_THRESHOLD  = 300.0   # return 1Y > 300% → suspicious
    # [P3] Dinaikkan dari 250%→300%: bukti empiris 38% saham IDX2 terflag
    # (174/452). Banyak saham komoditas/recovery naik organik 150-250%.
    # 300% hanya menangkap kenaikan yang benar-benar ekstrem/manipulatif.
    PND_PEAK_THRESHOLD    = 30.0    # harga < 30% ATH → crash post-pump
    PND_DRAWDOWN_THRESHOLD= -60.0   # max drawdown < -60% → pump-dump pattern
    PND_VOL_SPIKE_RATIO   = 6.0     # volume > 6x MA20
    PND_VOL_SPIKE_DAYS    = 3       # selama 3 hari berturut-turut
    # Volume spike hanya trigger flag jika return 1Y juga > 150% (dua syarat terpenuhi)
    PND_VOL_COMBO_RETURN  = 150.0

    flagged = set()
    if not backtest_results:
        return flagged

    for ticker in df_work["ticker"].tolist():
        res = backtest_results.get(ticker, {})
        df_price = res.get("df")
        if df_price is None or "Close" not in df_price.columns:
            continue
        if len(df_price) < 60:
            continue

        close = df_price["Close"].dropna()
        if len(close) < 60:
            continue

        try:
            # --- Syarat 1: return 1Y > 250% (threshold utama, dikembalikan ke level wajar) ---
            close_1y = close.tail(252)
            return_1y = 0.0
            if len(close_1y) >= 2 and close_1y.iloc[0] > 0:
                return_1y = (close_1y.max() / close_1y.iloc[0] - 1) * 100
                if return_1y > PND_RETURN_THRESHOLD:
                    flagged.add(ticker)
                    continue

            # --- Syarat 2: harga jauh di bawah ATH (crash post-pump) ---
            all_time_high = close.max()
            current_price = close.iloc[-1]
            if all_time_high > 0:
                price_vs_peak = (current_price / all_time_high) * 100
                if price_vs_peak < PND_PEAK_THRESHOLD:
                    flagged.add(ticker)
                    continue

            # --- Syarat 3: max drawdown ekstrem ---
            max_dd = res.get("max_drawdown", 0)
            if max_dd < PND_DRAWDOWN_THRESHOLD:
                flagged.add(ticker)
                continue

            # --- Syarat 4: volume spike PLUS return moderat (kombinasi dua faktor) ---
            # Satu faktor saja tidak cukup — butuh dua sinyal sekaligus.
            if "Volume" in df_price.columns and return_1y > PND_VOL_COMBO_RETURN:
                vol_series = df_price["Volume"].dropna()
                if len(vol_series) >= 25:
                    vol_ma20 = vol_series.rolling(20).mean()
                    vol_ratio = vol_series / vol_ma20.replace(0, np.nan)
                    recent_ratio = vol_ratio.dropna().tail(PND_VOL_SPIKE_DAYS)
                    if (len(recent_ratio) == PND_VOL_SPIKE_DAYS and
                            (recent_ratio > PND_VOL_SPIKE_RATIO).all()):
                        flagged.add(ticker)
                        continue

        except Exception:
            continue
    return flagged


def apply_absolute_quality_floor(df, label="selection"):
    """
    Absolute floor — TIDAK BOLEH dilewati Relax Mode.
    Gugur jika trades < 3 OR winrate < 25 OR sharpe < -1.5
    """
    if df is None or len(df) == 0:
        print(f"🔒 ABS FLOOR [{label}]: input kosong")
        return df

    d = df.copy()
    # normalisasi nama kolom
    col_map = {}
    for c in d.columns:
        cl = str(c).lower()
        if cl in ("trades", "trade"):
            col_map["trades"] = c
        elif cl in ("winrate", "win_rate", "win rate"):
            col_map["winrate"] = c
        elif cl == "sharpe":
            col_map["sharpe"] = c

    for need in ("trades", "winrate", "sharpe"):
        if need not in col_map:
            # coba exact
            if need in d.columns:
                col_map[need] = need
            elif need.title() in d.columns:
                col_map[need] = need.title()

    tcol = col_map.get("trades")
    wcol = col_map.get("winrate")
    scol = col_map.get("sharpe")

    if not all([tcol, wcol, scol]):
        print(f"⚠️ ABS FLOOR [{label}]: kolom tidak lengkap {list(d.columns)[:12]}")
        return d

    tr = pd.to_numeric(d[tcol], errors="coerce").fillna(0)
    wr = pd.to_numeric(d[wcol], errors="coerce").fillna(0)
    sh = pd.to_numeric(d[scol], errors="coerce").fillna(-999)

    fail_trades = tr < ABS_MIN_BACKTEST_TRADES
    fail_wr     = wr < ABS_MIN_WINRATE
    fail_sh     = sh < ABS_MIN_SHARPE
    fail_any    = fail_trades | fail_wr | fail_sh

    n_tr = int(fail_trades.sum())
    n_wr = int(fail_wr.sum())
    n_sh = int(fail_sh.sum())
    n_out = int(fail_any.sum())
    n_in = int((~fail_any).sum())

    print("\n" + "=" * 70)
    print(f"  🔒 ABSOLUTE QUALITY FLOOR [{label}]")
    print("=" * 70)
    print(f"  Syarat mutlak: trades≥{ABS_MIN_BACKTEST_TRADES} & WR≥{ABS_MIN_WINRATE}% & Sharpe≥{ABS_MIN_SHARPE}")
    print(f"  Gugur Trades  < {ABS_MIN_BACKTEST_TRADES:>4}: {n_tr}")
    print(f"  Gugur WinRate < {ABS_MIN_WINRATE:>4}%: {n_wr}")
    print(f"  Gugur Sharpe  < {ABS_MIN_SHARPE:>4}: {n_sh}")
    print(f"  Total gugur (unique rows): {n_out} | Lolos: {n_in}")
    print("=" * 70)

    return d.loc[~fail_any].copy()

def select_stocks_balanced(df, fundamental_dict=None, backtest_results=None):
    df_work = df.copy()
    
    required_cols = ["ticker", "trades", "avg_volume", "price"]
    for col in required_cols:
        if col not in df_work.columns:
            if col == "ticker":
                continue
            elif col == "trades":
                df_work["trades"] = 0
            elif col == "avg_volume":
                df_work["avg_volume"] = 1_000_000
            elif col == "price":
                df_work["price"] = 1000
    
    if fundamental_dict:
        def get_fund_value(ticker, field, default=0):
            fund = fundamental_dict.get(ticker, {})
            val = fund.get(field, default)
            if val is None or pd.isna(val):
                return default
            return val
        
        df_work["profitMargins"] = df_work["ticker"].apply(lambda x: get_fund_value(x, "profitMargins", 0.0))
        df_work["debtToEquity"] = df_work["ticker"].apply(lambda x: get_fund_value(x, "debtToEquity", 200.0))
        df_work["pegRatio"] = df_work["ticker"].apply(lambda x: get_fund_value(x, "pegRatio", 99.0))
    else:
        for col, default in [("profitMargins", 0.0), ("debtToEquity", 200.0), ("pegRatio", 99.0)]:
            if col not in df_work.columns:
                df_work[col] = default
    
    for col in ["profitMargins", "debtToEquity", "pegRatio"]:
        if col in df_work.columns:
            df_work[col] = pd.to_numeric(df_work[col], errors="coerce").fillna(0 if col == "profitMargins" else 200.0)
    
    print(f"\n📋 BEFORE HARD FILTER: {len(df_work)} stocks")
    
    min_trades = 1
    min_volume = 1_000_000
    
    df_filtered = df_work[
        (df_work["trades"] >= min_trades) &
        (df_work["avg_volume"] >= min_volume) &
        (df_work["price"] >= 50)
    ].copy()
    
    print(f"📋 AFTER HARD FILTER (strict): {len(df_filtered)} stocks")
    
    if len(df_filtered) == 0:
        print("⚠️ Melonggarkan filter ke tier 1 (volume >= 500,000, trades >= 3)...")
        df_filtered = df_work[
            (df_work["trades"] >= 3) &
            (df_work["avg_volume"] >= 500_000) &
            (df_work["price"] >= 50)
        ].copy()
        print(f"📋 AFTER HARD FILTER (tier 1): {len(df_filtered)} stocks")
    
    if len(df_filtered) == 0:
        # [BUG B FIX] tier 2: hapus syarat trades, volume sangat longgar
        print("⚠️ Melonggarkan filter ke tier 2 (volume >= 100,000, trades >= 0)...")
        df_filtered = df_work[
            (df_work["avg_volume"] >= 100_000) &
            (df_work["price"] >= 50)
        ].copy()
        print(f"📋 AFTER HARD FILTER (tier 2): {len(df_filtered)} stocks")
    
    if len(df_filtered) == 0:
        # [BUG B FIX] tier 3: hanya filter harga, tidak ada filter trades/volume
        print("⚠️ Melonggarkan filter ke tier 3 (hanya harga >= 50)...")
        df_filtered = df_work[(df_work["price"] >= 50)].copy()
        print(f"📋 AFTER HARD FILTER (tier 3): {len(df_filtered)} stocks")

    if len(df_filtered) == 0:
        print("⚠️ Semua tier gagal. Menggunakan semua saham tanpa filter...")
        df_filtered = df_work.copy()
        print(f"📋 AFTER FALLBACK FILTER (no filter): {len(df_filtered)} stocks")
    
    if backtest_results and len(df_filtered) > 0:
        try:
            pnd_flagged = detect_pump_and_dump(df_filtered, backtest_results)
            if pnd_flagged:
                df_filtered = df_filtered[~df_filtered["ticker"].isin(pnd_flagged)].copy()
                print(f"\n🚩 PUMP-AND-DUMP FILTER: {len(pnd_flagged)} saham dieksklusi")
        except Exception as e:
            print(f"\n⚠️ Pump-and-dump filter error: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # TIERED QUALITY GATE INTEGRATION
    # Rev 37.1.14 spec:
    #   Tier 1 (Premium)    : Sharpe≥0.5, WinRate≥50% → bonus +0.08
    #   Tier 2 (Good)       : Sharpe≥0.0, WinRate≥40% → penalti -0.04
    #   Tier 3 (Acceptable) : semua lain → penalti -0.10
    #                         HANYA masuk jika T1+T2 < TQG_MIN_T1T2 (8 saham)
    #
    # TIDAK mengubah Hybrid Relax Logic di atas.
    # TIDAK membuang saham secara permanen — hanya memberi label dan adjustment.
    # Tier 3 dikontrol masuknya: jika T1+T2 sudah ≥ 8, Tier 3 dikeluarkan.
    # Penalti/bonus diaplikasikan di Phase 4 Score SETELAH normalisasi.
    # ─────────────────────────────────────────────────────────────────────────
    if len(df_filtered) > 0:
        before_qg = len(df_filtered)

        # Pre-filter trades minimum (tidak mengubah pipeline utama)
        if "trades" in df_filtered.columns:
            qg = df_filtered[df_filtered["trades"] >= MIN_BACKTEST_TRADES].copy()
            if len(qg) >= 5:
                df_filtered = qg

        # TIERED QUALITY GATE INTEGRATION — assign tier ke setiap saham
        def _assign_tier_row(row):
            sh = pd.to_numeric(row.get("sharpe",  np.nan), errors="coerce")
            wr = pd.to_numeric(row.get("winrate", row.get("win_rate", np.nan)), errors="coerce")
            tier, adjustment, label = assign_quality_tier(sh, wr, 0)
            return pd.Series({
                "qg_tier":    tier,
                "qg_penalty": adjustment,   # positif=bonus, negatif=penalti
                "qg_label":   label
            })

        tier_cols = df_filtered.apply(_assign_tier_row, axis=1)
        df_filtered = pd.concat([
            df_filtered.reset_index(drop=True),
            tier_cols.reset_index(drop=True)
        ], axis=1)

        t1 = int((df_filtered["qg_tier"] == 1).sum())
        t2 = int((df_filtered["qg_tier"] == 2).sum())
        t3 = int((df_filtered["qg_tier"] == 3).sum())

        # TIERED QUALITY GATE INTEGRATION — Tier 3 conditional inclusion
        # Tier 3 hanya diizinkan masuk jika T1+T2 kurang dari TQG_MIN_T1T2
        if (t1 + t2) >= TQG_MIN_T1T2:
            # Cukup kandidat premium — keluarkan Tier 3
            before_t3 = len(df_filtered)
            df_filtered = df_filtered[df_filtered["qg_tier"] <= 2].copy()
            t3_removed = before_t3 - len(df_filtered)
            print(f"🏆 TIERED QUALITY GATE: T1★={t1} | T2={t2} | T3 dieksklusi ({t3_removed} saham)")
            print(f"   ✅ T1+T2={t1+t2} ≥ {TQG_MIN_T1T2} → Tier 3 tidak diperlukan")
        else:
            # Tidak cukup — izinkan Tier 3 masuk sebagai last resort
            print(f"🏆 TIERED QUALITY GATE: T1★={t1} | T2={t2} | T3={t3} (last resort)")
            print(f"   ⚠️  T1+T2={t1+t2} < {TQG_MIN_T1T2} → Tier 3 diizinkan masuk dengan penalti")

        if t1 > 0:
            print(f"   ✅ {t1} Tier 1 Premium: Sharpe≥{TQG_T1_SHARPE}, WinRate≥{TQG_T1_WINRATE}% (bonus {TIER1_BONUS:+.2f})")
        if t2 > 0:
            print(f"   ⚠️  {t2} Tier 2 Good: Sharpe≥{TQG_T2_SHARPE}, WinRate≥{TQG_T2_WINRATE}% (penalti {TIER2_PENALTY:+.2f})")
        if t3 > 0 and (t1 + t2) < TQG_MIN_T1T2:
            print(f"   ℹ️  {t3} Tier 3 Acceptable: semua lain (penalti {TIER3_PENALTY:+.2f})")

        # [3d] HL_SPREAD HARD FILTER — likuiditas intraday (tidak diubah)
        if backtest_results and len(df_filtered) > 0:
            hl_flag_tickers = set()
            for tkr in df_filtered["ticker"].tolist():
                _res = backtest_results.get(tkr, {})
                if _res.get("hl_spread_wide", False):
                    hl_flag_tickers.add(tkr)
            if hl_flag_tickers:
                before_hl = len(df_filtered)
                df_filtered = df_filtered[~df_filtered["ticker"].isin(hl_flag_tickers)].copy()
                print(f"📏 HL_SPREAD FILTER [3d]: {len(hl_flag_tickers)} dieksklusi, {before_hl}→{len(df_filtered)}")

        print(f"✅ TIERED QUALITY GATE selesai: {before_qg}→{len(df_filtered)} saham (tier label aktif)")
    # END TIERED QUALITY GATE INTEGRATION ─────────────────────────────────────
    
    if len(df_filtered) == 0:
        print("⚠️ WARNING: Tidak ada saham yang lolos filter!")
        return pd.DataFrame()
    
    scoring_cols = ["momentum_3m", "sharpe", "winrate", "max_drawdown", "consistency"]
    for col in scoring_cols:
        if col not in df_filtered.columns:
            if col == "momentum_3m":
                df_filtered["momentum_3m"] = df_filtered["return"].fillna(0) if "return" in df_filtered.columns else 0
            elif col == "sharpe":
                df_filtered["sharpe"] = df_filtered["sharpe"].fillna(0) if "sharpe" in df_filtered.columns else 0
            elif col == "winrate":
                df_filtered["winrate"] = df_filtered["win_rate"].fillna(0) if "win_rate" in df_filtered.columns else 0
            elif col == "max_drawdown":
                df_filtered["max_drawdown"] = df_filtered["max_drawdown"].fillna(-50) if "max_drawdown" in df_filtered.columns else -50
            elif col == "consistency":
                max_trades = df_filtered["trades"].max() if df_filtered["trades"].max() > 0 else 1
                wr_col = df_filtered["winrate"].fillna(0) if "winrate" in df_filtered.columns else pd.Series(0, index=df_filtered.index)
                df_filtered["consistency"] = (wr_col * (df_filtered["trades"] / max_trades)) / 100
    
    for col in scoring_cols:
        if col in df_filtered.columns:
            df_filtered[col] = pd.to_numeric(df_filtered[col], errors="coerce").fillna(0)
    
    def safe_normalize(col_or_series):
        try:
            if isinstance(col_or_series, str):
                s = df_filtered[col_or_series].fillna(0)
            else:
                s = col_or_series.fillna(0)
            return normalize(s)
        except Exception:
            return pd.Series([0.5] * len(df_filtered), index=df_filtered.index)
    
    df_filtered["score"] = (
        0.20 * safe_normalize("momentum_3m") +
        0.20 * safe_normalize("sharpe") +
        0.15 * safe_normalize("winrate") +
        0.15 * safe_normalize(-df_filtered["max_drawdown"]) +
        0.10 * safe_normalize("consistency") +
        0.10 * safe_normalize(df_filtered["avg_volume"]) +
        0.05 * safe_normalize(df_filtered["profitMargins"]) +
        0.05 * safe_normalize(-df_filtered["debtToEquity"])
    )
    
    if "debtToEquity" in df_filtered.columns:
        df_filtered.loc[df_filtered["debtToEquity"] > 150, "score"] *= 0.9
    if "pegRatio" in df_filtered.columns:
        df_filtered.loc[df_filtered["pegRatio"] > 2.0, "score"] *= 0.9
    
    ranked = df_filtered.sort_values("score", ascending=False)
    selected = ranked.head(min(10, len(ranked))).copy()
    
    if "max_drawdown" in selected.columns and "sharpe" in selected.columns:
        selected = selected[(selected["max_drawdown"] > -50.0) & (selected["sharpe"] > 0)].copy()
    
    if len(selected) == 0 and len(ranked) > 0:
        print("⚠️ Safety filter kosong, menggunakan top ranking tanpa safety filter")
        selected = ranked.head(min(10, len(ranked))).copy()
    
    return selected

def calculate_momentum_score(df):
    if len(df) == 0:
        return 0
    score = 0
    try:
        if "MA5" in df.columns and "MA20" in df.columns:
            if len(df) > 0 and not pd.isna(df["MA5"].iloc[-1]) and not pd.isna(df["MA20"].iloc[-1]):
                if df["MA5"].iloc[-1] > df["MA20"].iloc[-1]:
                    score += 1
        if "RSI" in df.columns:
            if len(df) > 0 and not pd.isna(df["RSI"].iloc[-1]) and df["RSI"].iloc[-1] > 50:
                score += 1
        if "MACD" in df.columns and "MACD_Signal" in df.columns:
            if len(df) > 0 and not pd.isna(df["MACD"].iloc[-1]) and not pd.isna(df["MACD_Signal"].iloc[-1]):
                if df["MACD"].iloc[-1] > df["MACD_Signal"].iloc[-1]:
                    score += 1
    except Exception:
        pass
    return score

def get_dynamic_t_df(returns):
    # [FT-7] Tambahkan skewness negatif sebagai faktor kedua.
    # Return IDX sering negatif-skewed (crash lebih sering dari pump).
    # Skewness negatif → df lebih kecil → lebih banyak simulasi extreme loss.
    if len(returns) < 30:
        return 5.0
    try:
        kurt = returns.kurtosis()
        if pd.isna(kurt):
            return 5.0
        t_df = 4.0 + 10.0 / (1.0 + abs(kurt))

        # Koreksi skewness: hanya skewness negatif yang dikurangi df
        try:
            skew = returns.skew()
            if not pd.isna(skew) and skew < 0:
                skew_penalty = min(abs(skew) * 0.4, 1.0)  # maks kurangi 1.0
                t_df -= skew_penalty
        except Exception:
            pass

        return float(max(3.0, min(8.0, t_df)))
    except Exception:
        return 5.0

def split_timeframes(df):
    # [BUG 9 FIX] .tail() menghasilkan view bukan copy → wajib .copy()
    return {
        "3Y": df.copy(),
        "1Y": df.tail(min(252, len(df))).copy(),
        "3M": df.tail(min(63, len(df))).copy()
    }

def adaptive_weighting(tf_results):
    # [FT-2] Bobot intraday: 3M mendapat porsi besar karena MAX_HOLDING=1 hari.
    # Data 3Y terlalu jauh secara konteks makro untuk prediksi besok.
    weights = {"3Y": 0.10, "1Y": 0.30, "3M": 0.60}
    try:
        dd_3m  = tf_results.get("3M",  {}).get("max_drawdown", 0)
        dd_1y  = tf_results.get("1Y",  {}).get("max_drawdown", 0)
        # Jika pasar sangat bergejolak (drawdown 3M < -20%), geser lebih ke 3M
        if dd_3m < -20:
            weights = {"3Y": 0.05, "1Y": 0.25, "3M": 0.70}
        # Jika 1Y juga buruk, andalkan 3M hampir penuh
        elif dd_1y < -25:
            weights = {"3Y": 0.05, "1Y": 0.20, "3M": 0.75}
    except Exception:
        pass
    return weights

def aggregate_multi_tf(tf_results):
    if not tf_results:
        return {"return": 0, "sharpe": 0, "win_rate": 0, "max_drawdown": 0, "trades": 0, "exit_reasons": {}}
    
    weights = adaptive_weighting(tf_results)
    agg = {"return": 0.0, "sharpe": 0.0, "win_rate": 0.0, "max_drawdown": 0.0, "trades": 0.0}
    total_weight = 0
    exit_reasons = {}
    
    for tf, res in tf_results.items():
        w = weights.get(tf, 0)
        total_weight += w
        agg["return"] += res.get("return", 0) * w
        agg["sharpe"] += res.get("sharpe", 0) * w
        agg["win_rate"] += res.get("win_rate", 0) * w
        agg["max_drawdown"] += res.get("max_drawdown", 0) * w
        agg["trades"] += res.get("trades", 0) * w
        # jumlahkan exit reasons (bukan rata-rata) — prioritas TF 3Y jika ada
        for reason, cnt in (res.get("exit_reasons") or {}).items():
            exit_reasons[reason] = exit_reasons.get(reason, 0) + int(cnt)

    if total_weight > 0:
        for key in list(agg.keys()):
            agg[key] = agg[key] / total_weight
    agg["exit_reasons"] = exit_reasons
    return agg

def is_intraday_active():
    return bool(INTRADAY_MODE)

# =============================================================
# ENHANCED BACKTEST FUNCTION
# =============================================================
def run_backtest_intraday(df, prior_sharpe=np.nan, adaptive_params=None):
    try:
        df = df.copy()  # [BUG 8 FIX] hindari modifikasi DataFrame asli (vol_ma20)
        capital = float(INITIAL_CAPITAL)
        position = 0
        entry_cost = 0.0
        entry_bar = 0
        stop_loss_price = 0.0
        take_profit_price = 0.0
        highest_price = 0.0
        trailing_stop_price = 0.0
        trades = []
        equity_curve = []

        if adaptive_params is None:
            adaptive_params = {
                "max_position_size": MAX_POSITION_SIZE,
                "atr_trailing_multiplier": ATR_TRAILING_MULTIPLIER,
                "min_profit_for_time_exit": MIN_PROFIT_FOR_TIME_EXIT,
                "volume_ratio_threshold_entry": VOLUME_RATIO_THRESHOLD,
            }
        
        adaptive_max_position_size = adaptive_params.get("max_position_size", MAX_POSITION_SIZE)
        adaptive_atr_multiplier = adaptive_params.get("atr_trailing_multiplier", ATR_TRAILING_MULTIPLIER)
        adaptive_min_profit = adaptive_params.get("min_profit_for_time_exit", MIN_PROFIT_FOR_TIME_EXIT)
        adaptive_volume_threshold = adaptive_params.get("volume_ratio_threshold_entry", VOLUME_RATIO_THRESHOLD)

        if "Volume" in df.columns:
            df["vol_ma20"] = df["Volume"].shift(1).rolling(20).mean()
        else:
            df["vol_ma20"] = np.nan

        for i in range(50, len(df)):
            if "Signal" not in df.columns:
                continue
                
            cur_sig = df["Signal"].iloc[i]
            cur_price = df["Close"].iloc[i]
            atr_val = df["ATR"].iloc[i] if "ATR" in df.columns else 0

            vol_today = df["vol_20"].iloc[i] if "vol_20" in df.columns else np.nan
            avg_vol = df["vol_100_avg"].iloc[i] if "vol_100_avg" in df.columns else np.nan
            
            volume_abs = df["Volume"].iloc[i] if "Volume" in df.columns else np.nan
            vol_ma20 = df["vol_ma20"].iloc[i] if "vol_ma20" in df.columns else np.nan

            try:
                bar_hour = df.index[i].hour + df.index[i].minute / 60.0
            except Exception:
                bar_hour = 0.0

            if pd.isna(cur_price):
                prev_price = df["Close"].iloc[i-1] if i-1 >= 0 else cur_price
                equity_curve.append(capital + (position * float(prev_price) if position > 0 else 0))
                continue

            cur_equity = capital + (position * float(cur_price) if position > 0 else 0)
            equity_curve.append(cur_equity)

            # EXIT LOGIC
            if position > 0:
                exit_reason = None

                if cur_price > highest_price:
                    highest_price = cur_price
                    if pd.notna(atr_val) and atr_val > 0:
                        new_trail = highest_price - (adaptive_atr_multiplier * float(atr_val))
                    else:
                        new_trail = highest_price * 0.95
                    if new_trail > trailing_stop_price:
                        trailing_stop_price = new_trail
                    if trailing_stop_price > stop_loss_price:
                        stop_loss_price = trailing_stop_price

                holding_days = i - entry_bar if entry_bar > 0 else 0
                
                spike_exit = (
                    pd.notna(vol_today) and pd.notna(avg_vol) and
                    avg_vol > 0 and vol_today > VOL_SPIKE_MULTIPLIER * avg_vol
                )
                
                price_change_5d = 0.0
                volume_declining = False
                if i >= 5:
                    price_5d_ago = df["Close"].iloc[i-5]
                    if price_5d_ago > 0:
                        price_change_5d = (cur_price - price_5d_ago) / price_5d_ago
                    
                    if pd.notna(volume_abs) and pd.notna(vol_ma20) and vol_ma20 > 0:
                        volume_declining = volume_abs < VOLUME_DIVERGENCE_THRESHOLD * vol_ma20
                
                divergence_exit = (price_change_5d > 0.02) and volume_declining
                
                current_pnl_pct = 0.0
                if entry_cost > 0:
                    current_value = position * cur_price
                    current_pnl_pct = (current_value - entry_cost) / entry_cost
                
                time_exit = (bar_hour >= EXIT_PROFIT_HOUR and current_pnl_pct < adaptive_min_profit)

                if cur_sig == "SELL":
                    exit_reason = "SIGNAL"
                elif trailing_stop_price > 0 and cur_price <= trailing_stop_price:
                    exit_reason = "TRAILING STOP"
                elif stop_loss_price > 0 and cur_price <= stop_loss_price:
                    exit_reason = "STOP LOSS"
                elif take_profit_price > 0 and cur_price >= take_profit_price:
                    exit_reason = "TAKE PROFIT"
                elif spike_exit:
                    exit_reason = "VOL SPIKE EXIT"
                elif divergence_exit:
                    exit_reason = "VOL DIVERGENCE EXIT"
                elif time_exit:
                    exit_reason = "TIME EXIT (14:30 - NO PROFIT)"
                elif holding_days > MAX_HOLDING_DAYS and current_pnl_pct < adaptive_min_profit:
                    exit_reason = "MAX HOLDING EXIT"

                if exit_reason:
                    # [FIX-P2] Exit juga pakai TC/2 (konsisten dengan entry fix)
                    revenue = position * float(cur_price) * (1 - TRANSACTION_COST / 2)
                    pnl = revenue - entry_cost
                    capital += revenue
                    trades.append({
                        "date": df.index[i], "type": "SELL", "price": float(cur_price),
                        "shares": position, "pnl": pnl,
                        "return_pct": (pnl / entry_cost) * 100 if entry_cost > 0 else 0,
                        "reason": exit_reason, "highest_price": highest_price,
                        "holding_days": holding_days,
                    })
                    position = 0
                    entry_bar = 0
                    stop_loss_price = 0.0
                    take_profit_price = 0.0
                    highest_price = 0.0
                    trailing_stop_price = 0.0

            # ENTRY LOGIC
            elif cur_sig == "BUY" and position == 0:
                volume_filter_ok = True
                if pd.notna(volume_abs) and pd.notna(vol_ma20) and vol_ma20 > 0:
                    volume_ratio = volume_abs / vol_ma20
                    if volume_ratio < adaptive_volume_threshold:
                        volume_filter_ok = False
                
                if not volume_filter_ok:
                    continue
                
                rr_filter_ok = True
                if pd.notna(atr_val) and atr_val > 0:
                    sl_distance_pct = (adaptive_atr_multiplier * float(atr_val)) / float(cur_price)
                    if sl_distance_pct > MAX_SL_DISTANCE_PCT:
                        rr_filter_ok = False
                
                if not rr_filter_ok:
                    continue
                
                stock_volatility = vol_today
                if pd.notna(stock_volatility) and stock_volatility > 0:
                    position_size = TARGET_VOL_DAILY / float(stock_volatility)
                else:
                    position_size = DEFAULT_RISK_SIZE

                if pd.notna(prior_sharpe):
                    if prior_sharpe > SHARPE_HIGH_THRESH:
                        position_size *= SHARPE_SCALE_UP
                    elif prior_sharpe < SHARPE_LOW_THRESH:
                        position_size *= SHARPE_SCALE_DOWN
                
                position_size = min(position_size, adaptive_max_position_size)
                alloc_capital = capital * position_size

                if pd.notna(atr_val) and atr_val > 0:
                    sl_dist = adaptive_atr_multiplier * float(atr_val)
                    sl_price = float(cur_price) - sl_dist
                    tp_price = float(cur_price) + 3 * sl_dist
                else:
                    sl_price = float(cur_price) * 0.95
                    tp_price = float(cur_price) * 1.10

                shares = int(alloc_capital / float(cur_price)) if cur_price > 0 else 0

                if shares > 0:
                    # [FIX-P2] TC dibagi 2 karena TRANSACTION_COST=0.003 adalah round-trip.
                    # Versi lama: entry pakai TC penuh (1+0.003) DAN exit pakai TC penuh (1-0.003)
                    # → total drag 0.6% per trade, break-even WR naik ke 49% (terlalu tinggi).
                    # Fix: setiap sisi bayar TC/2 = 0.15% → total 0.3% round-trip yang benar.
                    cost = shares * float(cur_price) * (1 + TRANSACTION_COST / 2)
                    if cost <= capital:
                        entry_bar = i
                        highest_price = float(cur_price)
                        if pd.notna(atr_val) and atr_val > 0:
                            trailing_stop_price = highest_price - (adaptive_atr_multiplier * float(atr_val))
                        else:
                            trailing_stop_price = highest_price * 0.95
                        position = shares
                        entry_cost = cost
                        stop_loss_price = max(sl_price, trailing_stop_price)
                        take_profit_price = tp_price
                        capital -= cost

        final_price = float(df["Close"].iloc[-1]) if len(df) > 0 and not pd.isna(df["Close"].iloc[-1]) else 0
        final_equity = capital + (position * final_price if position > 0 else 0)
        total_return = (final_equity - INITIAL_CAPITAL) / INITIAL_CAPITAL * 100

        equity_series = pd.Series(equity_curve)
        daily_ret = equity_series.pct_change().dropna()
        sharpe = calc_sharpe(daily_ret)

        eq_arr = np.array(equity_curve)
        if len(eq_arr) > 0:
            peak = np.maximum.accumulate(eq_arr)
            peak_safe = np.where(peak == 0, 1, peak)
            dd = (eq_arr - peak) / peak_safe
            max_dd = float(dd.min()) * 100
        else:
            max_dd = 0.0

        n_sell = len([t for t in trades if t.get("type") == "SELL"])
        n_win = len([t for t in trades if t.get("type") == "SELL" and t.get("pnl", 0) > 0])
        win_rate = (n_win / n_sell * 100) if n_sell > 0 else 0.0
        
        avg_holding = np.mean([t.get("holding_days", 0) for t in trades if t.get("type") == "SELL"]) if n_sell > 0 else 0
        
        exit_reasons = {}
        for t in trades:
            if t.get("type") == "SELL":
                reason = t.get("reason", "UNKNOWN")
                exit_reasons[reason] = exit_reasons.get(reason, 0) + 1

        return {
            "return": total_return, "sharpe": sharpe if not pd.isna(sharpe) else 0.0,
            "win_rate": win_rate, "max_drawdown": max_dd, "trades": n_sell,
            "avg_holding_days": avg_holding, "exit_reasons": exit_reasons,
        }

    except Exception as e:
        print(f"   ⚠️ Backtest error: {str(e)[:100]}")
        return {
            "return": 0, "sharpe": 0.0, "win_rate": 0.0,
            "max_drawdown": 0.0, "trades": 0, "avg_holding_days": 0, "exit_reasons": {},
        }

# =============================================================
# MONTE CARLO FORECAST
# =============================================================
def monte_carlo_forecast(df, days=3, n_sim=1000, method="sobol"):
    try:
        df = df.copy()
        df["return"] = df["Close"].pct_change()

        hist_mean = df["return"].mean()
        hist_std = df["return"].std()

        if pd.isna(hist_mean) or pd.isna(hist_std) or hist_std == 0 or len(df) < 50:
            current_price = float(df["Close"].iloc[-1]) if len(df) > 0 and not pd.isna(df["Close"].iloc[-1]) else 0
            return {
                "current_price": current_price, "median_price": current_price,
                "median_return": 0, "prob_up": 50, "range_min": -5, "range_max": 5,
                "method": "error", "momentum_score": 0, "t_df": 5.0,
                "std_used": 0, "vol_source": "error", "error": "Insufficient data", "garch_used": False
            }

        current_price = float(df["Close"].iloc[-1])
        momentum_score = calculate_momentum_score(df)
        adjusted_mean = hist_mean + (momentum_score * MOMENTUM_ADJ_FACTOR)
        t_df = get_dynamic_t_df(df["return"].dropna())

        std = hist_std if hist_std is not None and not pd.isna(hist_std) and hist_std > 0 else 0.01
        vol_source = "historical"
        garch_used = False

        if USE_GARCH_VOL and ARCH_AVAILABLE and len(df) >= 100:
            try:
                returns_pct = df["return"].dropna() * 100
                if len(returns_pct) >= 50:
                    am = arch_model(returns_pct, vol='Garch', p=GARCH_P, q=GARCH_Q,
                                    dist='Normal', rescale=False)
                    res = am.fit(disp='off', show_warning=False)
                    if hasattr(res, 'conditional_volatility') and len(res.conditional_volatility) > 0:
                        cond_vol = float(res.conditional_volatility.iloc[-1]) / 100.0
                        if cond_vol > 0.0001 and not pd.isna(cond_vol):
                            std = cond_vol
                            garch_used = True
                            vol_source = f"GARCH({GARCH_P},{GARCH_Q})"
            except Exception:
                vol_source = "historical (GARCH failed)"

        if t_df > 2:
            t_var_scale = float(np.sqrt(t_df / (t_df - 2))) if t_df > 2 else 1.0
        else:
            t_var_scale = 1.0

        simulated_prices = []
        use_fallback = True
        actual_method = "random-t"

        if QMC_AVAILABLE and _scipy_t is not None and method.lower() == "sobol":
            try:
                n_sim_actual = max(2 ** int(np.log2(n_sim)), 128)
                sampler = qmc.Sobol(d=days, scramble=True, seed=42)
                samples = sampler.random(n=n_sim_actual)
                samples = np.clip(samples, 1e-6, 1.0 - 1e-6)
                t_shocks = _scipy_t.ppf(samples, df=t_df)

                for sim_i in range(n_sim_actual):
                    price = current_price
                    for d in range(days):
                        shock_rescaled = t_shocks[sim_i, d] / t_var_scale
                        daily_return = adjusted_mean + (shock_rescaled * std)
                        price *= (1 + daily_return)
                    simulated_prices.append(price)
                use_fallback = False
                actual_method = "sobol-t"
            except Exception as e:
                print(f"   ⚠️ Sobol QMC error: {e}, fallback to random")

        if use_fallback or len(simulated_prices) == 0:
            np.random.seed(42)
            for _ in range(n_sim):
                price = current_price
                for _ in range(days):
                    t_raw = float(np.random.standard_t(df=t_df))
                    shock_rescaled = t_raw / t_var_scale
                    daily_return = adjusted_mean + (shock_rescaled * std)
                    price *= (1 + daily_return)
                simulated_prices.append(price)
            actual_method = "random-t"

        simulated_prices = np.array(simulated_prices)

        return {
            "current_price": current_price,
            "median_price": float(np.median(simulated_prices)),
            "median_return": float((np.median(simulated_prices) / current_price - 1) * 100),
            "prob_up": float(np.mean(simulated_prices > current_price) * 100),
            "range_min": float((np.percentile(simulated_prices, 20) / current_price - 1) * 100),
            "range_max": float((np.percentile(simulated_prices, 80) / current_price - 1) * 100),
            "method": actual_method, "momentum_score": momentum_score,
            "t_df": round(t_df, 2), "std_used": float(std),
            "vol_source": vol_source, "garch_used": garch_used, "error": None
        }
    except Exception as e:
        return {
            "current_price": 0, "median_price": 0, "median_return": 0, "prob_up": 50,
            "range_min": -5, "range_max": 5, "method": "error", "momentum_score": 0,
            "t_df": 5.0, "std_used": 0, "vol_source": "error", "error": str(e), "garch_used": False
        }

# =============================================================
# MONTE CARLO GATEKEEPER
# =============================================================
def run_monte_carlo_single(ticker: str, current_price: float, stop_loss: float,
                           take_profit: float, mu: float, sigma: float, signal_in: str) -> dict:
    if _scipy_t is None:
        return {"Ticker": ticker, "P_SL_%": 50.0, "P_TP_%": 10.0, "EV_Rp": 0,
                "MC_Decision": "BUY", "Signal_Final": signal_in}
    
    if sigma is None or np.isnan(sigma) or sigma <= 0:
        sigma = current_price * 0.02
    
    if mu is None or np.isnan(mu):
        mu = 0.0
    
    returns = _scipy_t.rvs(df=DF_STUDENT, loc=mu, scale=sigma, size=N_SIMULATIONS)
    prices_end = current_price * (1 + returns)

    hit_sl = np.sum(prices_end <= stop_loss)
    hit_tp = np.sum(prices_end >= take_profit)

    p_sl = hit_sl / N_SIMULATIONS
    p_tp = hit_tp / N_SIMULATIONS
    p_neither = 1 - p_sl - p_tp

    sl_loss = stop_loss - current_price
    tp_gain = take_profit - current_price

    # [BUG FIX ②] mid_val = 0 terlalu konservatif untuk intraday HORIZON=1.
    # Bukti: p_neither ≈ 100% untuk hampir semua saham → EV = 0 selalu.
    # Floating-point membuat EV sedikit negatif → semua WATCH.
    #
    # Fix: mid_val = median unrealized P&L dari path yang tidak kena SL/TP.
    # Artinya: kalau mayoritas path bergerak positif meski tidak menyentuh TP,
    # EV tetap positif dan saham layak BUY. Ini lebih jujur secara ekonomi —
    # posisi yang ditutup manual di akhir hari masih punya nilai realisasi.
    neither_mask = (prices_end > stop_loss) & (prices_end < take_profit)
    if np.sum(neither_mask) > 0:
        prices_neither = prices_end[neither_mask]
        mid_val = float(np.median(prices_neither) - current_price)
    else:
        mid_val = 0.0

    ev = (p_tp * tp_gain) + (p_sl * sl_loss) + (p_neither * mid_val)

    # EV threshold: gunakan sedikit buffer negatif (-5 rupiah) untuk toleransi
    # noise floating-point, agar saham yang EV ≈ 0 tidak langsung jadi WATCH.
    EV_MIN_THRESHOLD = -5.0

    if p_sl > P_SL_WATCH or ev < EV_MIN_THRESHOLD:
        mc_decision = "WATCH"
    elif p_sl < P_SL_STRONG and ev > 0:
        mc_decision = "STRONG BUY"
    else:
        mc_decision = "BUY"
    
    signal_out = mc_decision
    
    print(f"   🎲 MC [{ticker}]: P_SL={p_sl*100:.1f}% | P_TP={p_tp*100:.1f}% | "
          f"EV=Rp{ev:+.0f} | {signal_in} → {signal_out}")
    
    return {"Ticker": ticker, "P_SL_%": round(p_sl * 100, 1), "P_TP_%": round(p_tp * 100, 1),
            "EV_Rp": round(ev, 0), "MC_Decision": mc_decision, "Signal_Final": signal_out}

def run_monte_carlo_batch(selected_df, garch_params_dict: dict) -> pd.DataFrame:
    print("\n" + "=" * 78)
    print("  🎲 PHASE 3b: MONTE CARLO GATEKEEPER (Student-t, df=5)")
    print(f"     Simulasi: {N_SIMULATIONS} paths per saham, horizon {HORIZON} hari")
    print("=" * 78)
    
    if selected_df.empty:
        print("   ⚠️ Tidak ada saham untuk disimulasi")
        return pd.DataFrame()
    
    mc_results = []
    for idx, row in selected_df.iterrows():
        ticker = row["Ticker"]
        price = row.get("Close", row.get("Current_Price", 0))
        
        if price <= 0:
            print(f"   ⚠️ {ticker}: Harga tidak valid ({price}), skip")
            continue
        
        sl = row.get("Stop_Loss", row.get("Stop Loss", 0))
        tp = row.get("Take_Profit", row.get("Take Profit", 0))
        
        if sl == 0 or tp == 0:
            atr_val = row.get("ATR", price * 0.02)
            sl = price - (2 * atr_val)
            tp = price + (6 * atr_val)
        
        signal = row.get("Signal", "BUY")
        garch = garch_params_dict.get(ticker, {})
        mu = garch.get("mu", 0.0)
        sigma = garch.get("sigma", price * 0.02)
        
        result = run_monte_carlo_single(ticker, price, sl, tp, mu, sigma, signal)
        mc_results.append(result)
    
    if not mc_results:
        print("   ⚠️ Tidak ada hasil simulasi")
        return pd.DataFrame()
    
    mc_df = pd.DataFrame(mc_results)
    
    watch_count = sum(mc_df["MC_Decision"] == "WATCH")
    strong_count = sum(mc_df["MC_Decision"] == "STRONG BUY")
    buy_count = sum(mc_df["MC_Decision"] == "BUY")
    
    print("\n" + "=" * 78)
    print("  📊 MONTE CARLO GATEKEEPER SUMMARY")
    print("=" * 78)
    print(f"   ✅ STRONG BUY : {strong_count} saham (P_SL < 40% & EV > 0)")
    print(f"   ✅ BUY        : {buy_count} saham (P_SL 40-60% & EV >= 0)")
    print(f"   ⚠️ WATCH      : {watch_count} saham (P_SL > 60% atau EV < 0)")
    print("=" * 78)
    
    return mc_df

# =============================================================
# TICKER LIST - FULL IDX Universe (IDX2 BENAR — 561 saham)
# =============================================================
idx_tickers = [
    "AADI.JK", "ACRO.JK", "ACST.JK", "ADCP.JK", "ADES.JK", "ADMF.JK", "ADMR.JK",
    "AEGS.JK", "AGAR.JK", "AGII.JK", "AGRS.JK", "AHAP.JK", "AISA.JK", "AKKU.JK",
    "AKPI.JK", "AKSI.JK", "ALDO.JK", "ALII.JK", "ALKA.JK", "ALMI.JK", "ALTO.JK",
    "AMAG.JK", "AMAN.JK", "AMAR.JK", "AMIN.JK", "AMMN.JK", "AMMS.JK", "AMOR.JK",
    "APIC.JK", "APII.JK", "APLI.JK", "ARCI.JK", "AREA.JK", "ARGO.JK", "ARKA.JK",
    "ARKO.JK", "ARTA.JK", "ASGR.JK", "ASHA.JK", "ASJT.JK", "ASLC.JK", "ASLI.JK",
    "ASMI.JK", "ASPI.JK", "ASPR.JK", "ATAP.JK", "ATIC.JK", "ATLA.JK", "AVIA.JK",
    "AWAN.JK", "AXIO.JK", "AYAM.JK", "AYLS.JK", "BABP.JK", "BABY.JK", "BACA.JK",
    "BAIK.JK", "BAJA.JK", "BANK.JK", "BAPI.JK", "BATR.JK", "BAUT.JK", "BBLD.JK",
    "BBSI.JK", "BBSS.JK", "BCIC.JK", "BDKR.JK", "BEBS.JK", "BEEF.JK", "BEER.JK",
    "BELI.JK", "BELL.JK", "BESS.JK", "BHAT.JK", "BIKE.JK", "BIMA.JK", "BINA.JK",
    "BINO.JK", "BKDP.JK", "BLES.JK", "BLOG.JK", "BLTZ.JK", "BLUE.JK", "BMBL.JK",
    "BMHS.JK", "BMSR.JK", "BMTR.JK", "BNBR.JK", "BOAT.JK", "BOBA.JK", "BOGA.JK",
    "BOLA.JK", "BPFI.JK", "BPII.JK", "BPTR.JK", "BRAM.JK", "BREN.JK", "BRRC.JK",
    "BSBK.JK", "BSML.JK", "BTEK.JK", "BTON.JK", "BUAH.JK", "BUDI.JK", "BUKK.JK",
    "BUVA.JK", "CAKK.JK", "CAMP.JK", "CANI.JK", "CARS.JK", "CASA.JK", "CBDK.JK",
    "CBPE.JK", "CBRE.JK", "CBUT.JK", "CCSI.JK", "CDIA.JK", "CFIN.JK", "CGAS.JK",
    "CHEK.JK", "CHEM.JK", "CHIP.JK", "CINT.JK", "CLAY.JK", "CLPI.JK", "CMNP.JK",
    "CMNT.JK", "CMPP.JK", "CNMA.JK", "COAL.JK", "COCO.JK", "COIN.JK", "CPRO.JK",
    "CRAB.JK", "CRSN.JK", "CSIS.JK", "CSMI.JK", "CSRA.JK", "CTBN.JK", "CUAN.JK",
    "CYBR.JK", "DAAZ.JK", "DADA.JK", "DATA.JK", "DAYA.JK", "DEFI.JK", "DEPO.JK",
    "DEWI.JK", "DFAM.JK", "DGIK.JK", "DGNS.JK", "DGWG.JK", "DIGI.JK", "DIVA.JK",
    "DKHH.JK", "DMMX.JK", "DMND.JK", "DNET.JK", "DOOH.JK", "DPNS.JK", "DPUM.JK",
    "DRMA.JK", "DSFI.JK", "DSSA.JK", "DYAN.JK", "EAST.JK", "ECII.JK", "ELIT.JK",
    "ELPI.JK", "ELTY.JK", "EMAS.JK", "ENAK.JK", "ENZO.JK", "EPAC.JK", "EPMT.JK",
    "ERAL.JK", "ERTX.JK", "ESTA.JK", "ESTI.JK", "EURO.JK", "FAPA.JK", "FILM.JK",
    "FIMP.JK", "FIRE.JK", "FISH.JK", "FITT.JK", "FLMC.JK", "FOLK.JK", "FOOD.JK",
    "FORE.JK", "FORU.JK", "FPNI.JK", "FUJI.JK", "FWCT.JK", "GDST.JK", "GEMA.JK",
    "GGRM.JK", "GGRP.JK", "GLVA.JK", "GMFI.JK", "GOLD.JK", "GOLF.JK", "GPSO.JK",
    "GRIA.JK", "GRPH.JK", "GRPM.JK", "GSMF.JK", "GTRA.JK", "GULA.JK", "GUNA.JK",
    "HAIS.JK", "HAJJ.JK", "HALO.JK", "HATM.JK", "HBAT.JK", "HDFA.JK", "HDIT.JK",
    "HEXA.JK", "HGII.JK", "HILL.JK", "HOMI.JK", "HOPE.JK", "HRME.JK", "HUMI.JK",
    "HYGN.JK", "IATA.JK", "IBFN.JK", "IBOS.JK", "ICON.JK", "IDEA.JK", "IFII.JK",
    "IFSH.JK", "IKAI.JK", "IKAN.JK", "IKBI.JK", "IKPM.JK", "IMAS.JK", "IMJS.JK",
    "INCF.JK", "INCI.JK", "INDO.JK", "INDR.JK", "INDX.JK", "INOV.JK", "INPS.JK",
    "INTA.JK", "INTD.JK", "IOTF.JK", "IPAC.JK", "IPCC.JK", "IPPE.JK", "IPTV.JK",
    "IRRA.JK", "IRSX.JK", "ISAP.JK", "ISEA.JK", "ITIC.JK", "JARR.JK", "JAST.JK",
    "JATI.JK", "JAWA.JK", "JAYA.JK", "JGLE.JK", "JIHD.JK", "JKON.JK", "JMAS.JK",
    "JSPT.JK", "JTPE.JK", "KAEF.JK", "KAQI.JK", "KARW.JK", "KBAG.JK", "KBLV.JK",
    "KDTN.JK", "KEEN.JK", "KETR.JK", "KICI.JK", "KING.JK", "KINO.JK", "KIOS.JK",
    "KJEN.JK", "KKES.JK", "KLAS.JK", "KLIN.JK", "KMDS.JK", "KMTR.JK", "KOBX.JK",
    "KOCI.JK", "KOKA.JK", "KONI.JK", "KOTA.JK", "KRAS.JK", "KREN.JK", "KRYA.JK",
    "KSIX.JK", "KUAS.JK", "LABA.JK", "LABS.JK", "LAJU.JK", "LAND.JK", "LAPD.JK",
    "LCKM.JK", "LFLO.JK", "LIFE.JK", "LIVE.JK", "LMAX.JK", "LMPI.JK", "LOPI.JK",
    "LPIN.JK", "LPLI.JK", "LPPS.JK", "LUCY.JK", "MAHA.JK", "MAIN.JK", "MANG.JK",
    "MAPA.JK", "MAPB.JK", "MARI.JK", "MARK.JK", "MASB.JK", "MAXI.JK", "MAYA.JK",
    "MBMA.JK", "MBTO.JK", "MCOL.JK", "MCOR.JK", "MDIA.JK", "MDIY.JK", "MDKI.JK",
    "MDLA.JK", "MDRN.JK", "MEDS.JK", "MEGA.JK", "MEJA.JK", "MENN.JK", "MERI.JK",
    "MGLV.JK", "MGNA.JK", "MGRO.JK", "MICE.JK", "MIDI.JK", "MINA.JK", "MINE.JK",
    "MKAP.JK", "MKNT.JK", "MKTR.JK", "MLPL.JK", "MMIX.JK", "MMLP.JK", "MOLI.JK",
    "MPIX.JK", "MPRO.JK", "MPXL.JK", "MRAT.JK", "MSIE.JK", "MSIN.JK", "MSJA.JK",
    "MSKY.JK", "MSTI.JK", "MTEL.JK", "MTMH.JK", "MTPS.JK", "MTWI.JK", "MUTU.JK",
    "MYTX.JK", "NAIK.JK", "NANO.JK", "NASA.JK", "NASI.JK", "NATO.JK", "NAYZ.JK",
    "NCKL.JK", "NEST.JK", "NETV.JK", "NICE.JK", "NICK.JK", "NICL.JK", "NINE.JK",
    "NPGF.JK", "NSSS.JK", "NTBK.JK", "NZIA.JK", "OASA.JK", "OBAT.JK", "OBMD.JK",
    "OILS.JK", "OKAS.JK", "OLIV.JK", "OMED.JK", "OPMS.JK", "PACK.JK", "PADA.JK",
    "PAMG.JK", "PANI.JK", "PANR.JK", "PART.JK", "PBRX.JK", "PBSA.JK", "PDES.JK",
    "PDPP.JK", "PEVE.JK", "PGJO.JK", "PGUN.JK", "PICO.JK", "PIPA.JK", "PJHB.JK",
    "PLAN.JK", "PLIN.JK", "PMJS.JK", "PMMP.JK", "PMUI.JK", "PNBN.JK", "PNSE.JK",
    "POLA.JK", "POLI.JK", "POLU.JK", "POLY.JK", "PPGL.JK", "PPRE.JK", "PPRI.JK",
    "PRAY.JK", "PRDA.JK", "PRIM.JK", "PSAT.JK", "PSGO.JK", "PSKT.JK", "PTDU.JK",
    "PTMP.JK", "PTMR.JK", "PTPS.JK", "PTPW.JK", "PTSP.JK", "PUDP.JK", "PURA.JK",
    "PURI.JK", "PZZA.JK", "RAAM.JK", "RAFI.JK", "RALS.JK", "RATU.JK", "RBMS.JK",
    "RCCC.JK", "REAL.JK", "RELF.JK", "RGAS.JK", "RISE.JK", "RLCO.JK", "RMKE.JK",
    "RMKO.JK", "ROCK.JK", "RONY.JK", "RSCH.JK", "RSGK.JK", "RUNS.JK", "SAGE.JK",
    "SAMF.JK", "SAPX.JK", "SATU.JK", "SBMA.JK", "SCCO.JK", "SCNP.JK", "SDPC.JK",
    "SEMA.JK", "SICO.JK", "SILO.JK", "SINI.JK", "SKBM.JK", "SKRN.JK", "SLIS.JK",
    "SMBR.JK", "SMGA.JK", "SMIL.JK", "SMKL.JK", "SMKM.JK", "SMLE.JK", "SMMA.JK",
    "SMSM.JK", "SNLK.JK", "SOFA.JK", "SOLA.JK", "SONA.JK", "SOSS.JK", "SOTS.JK",
    "SOUL.JK", "SPMA.JK", "SPRE.JK", "SPTO.JK", "SQMI.JK", "SRAJ.JK", "SSIA.JK",
    "STAA.JK", "STAR.JK", "STRK.JK", "STTP.JK", "SUNI.JK", "SUPA.JK", "SUPR.JK",
    "SURI.JK", "SWAT.JK", "SWID.JK", "TALF.JK", "TAYS.JK", "TBMS.JK", "TCID.JK",
    "TCPI.JK", "TEBE.JK", "TFAS.JK", "TGKA.JK", "TGRA.JK", "TGUK.JK", "TIFA.JK",
    "TINS.JK", "TIRA.JK", "TLDN.JK", "TMPO.JK", "TNCA.JK", "TOOL.JK", "TOPS.JK",
    "TOSK.JK", "TPIA.JK", "TRGU.JK", "TRIN.JK", "TRIS.JK", "TRON.JK", "TRUE.JK",
    "TRUK.JK", "TRUS.JK", "TYRE.JK", "UANG.JK", "UCID.JK", "UDNG.JK", "UFOE.JK",
    "UNIQ.JK", "UNTD.JK", "UVCR.JK", "VAST.JK", "VERN.JK", "VICO.JK", "VISI.JK",
    "VIVA.JK", "VTNY.JK", "WAPO.JK", "WBSA.JK", "WEHA.JK", "WGSH.JK", "WICO.JK",
    "WIDI.JK", "WINE.JK", "WINR.JK", "WINS.JK", "WMPP.JK", "WOMF.JK", "WOWS.JK",
    "XCIS.JK", "YOII.JK", "YULE.JK", "YUPI.JK", "ZATA.JK", "ZBRA.JK", "ZONE.JK",
    "ZYRX.JK"
]


# === TAHAP3: smoke / liquid universe hook ===
import os as _os
_RUN_SMOKE = _os.environ.get("RUN_SMOKE", "0") == "1"
_RUN_LIQUID = _os.environ.get("RUN_LIQUID", "0") == "1"
if _RUN_SMOKE or _RUN_LIQUID:
    from pathlib import Path as _P
    _base = _P("/content/drive/MyDrive/Trading_Aladdin")
    _src = _base / ("universe_smoke20.txt" if _RUN_SMOKE else "universe_liquid.txt")
    if _src.exists():
        idx_tickers = [ln.strip() for ln in _src.read_text().splitlines() if ln.strip()]
        print(f"🎲 TAHAP3 override universe: {len(idx_tickers)} tickers from {_src.name}")
# === END TAHAP3 ===

print(f"✅ {len(idx_tickers)} saham IDX terdaftar (FULL Universe)\n")

# =============================================================
# 2. DATA LAYER
# =============================================================
def _extract_ticker_from_raw(raw, ticker):
    if isinstance(raw.columns, pd.MultiIndex):
        tickers_in_raw = raw.columns.get_level_values(1).unique().tolist()
        if ticker not in tickers_in_raw:
            return pd.DataFrame()
        try:
            td = raw.xs(ticker, level=1, axis=1).copy()
        except KeyError:
            return pd.DataFrame()
    else:
        td = raw.copy()
    td.columns = [c.title() if isinstance(c, str) else c for c in td.columns]
    return td

def download_batch_optimized(tickers):
    all_close, all_high, all_low, all_volume, all_open = {}, {}, {}, {}, {}
    n_batch = max(1, (len(tickers) + BATCH_SIZE - 1) // BATCH_SIZE)

    for b in range(n_batch):
        batch = tickers[b * BATCH_SIZE : (b + 1) * BATCH_SIZE]
        if not batch:
            continue

        try:
            end_date = datetime.today()
            start_date = end_date - timedelta(days=365 * 3)

            for retry in range(3):
                try:
                    raw = yf.download(batch, start=start_date, end=end_date,
                                      progress=False, auto_adjust=True)
                    break
                except Exception:
                    if retry == 2:
                        raise
                    time.sleep(2)

            if raw is None or raw.empty:
                print(f"   Batch {b+1}: No data received")
                continue

            for ticker in batch:
                try:
                    td = _extract_ticker_from_raw(raw, ticker)
                    if td.empty or 'Close' not in td.columns:
                        continue
                    all_close[ticker]  = td['Close'].dropna()
                    all_high[ticker]   = td['High'].dropna()   if 'High'   in td.columns else all_close[ticker].copy()
                    all_low[ticker]    = td['Low'].dropna()    if 'Low'    in td.columns else all_close[ticker].copy()
                    all_volume[ticker] = td['Volume'].dropna() if 'Volume' in td.columns else pd.Series(dtype=float)
                    # [3a] Aktifkan Open — tersedia di yfinance, dibutuhkan untuk candle pattern
                    all_open[ticker]   = td['Open'].dropna()   if 'Open'   in td.columns else all_close[ticker].copy()
                except Exception as e:
                    print(f"   Error extracting {ticker}: {e}")
                    continue

            n_ok = len([k for k in all_close if k in batch])
            print(f"   Batch {b+1}/{n_batch} selesai ({n_ok}/{len(batch)} saham)")
            time.sleep(0.5)

        except Exception as e:
            print(f"   Batch {b+1} error: {e}")
            continue

    if not all_close:
        raise ValueError("Gagal download data harga - semua batch kosong")

    idx_ref = max(all_close.values(), key=len).index

    price_close  = pd.DataFrame({t: s.reindex(idx_ref) for t, s in all_close.items()})
    price_high   = pd.DataFrame({t: s.reindex(idx_ref) for t, s in all_high.items()})
    price_low    = pd.DataFrame({t: s.reindex(idx_ref) for t, s in all_low.items()})
    price_volume = pd.DataFrame({t: s.reindex(idx_ref) for t, s in all_volume.items()}) if all_volume else pd.DataFrame(index=idx_ref)
    # [3a] price_open kini tersedia untuk seluruh pipeline
    price_open   = pd.DataFrame({t: s.reindex(idx_ref) for t, s in all_open.items()})  if all_open  else pd.DataFrame(index=idx_ref)

    return price_close, price_high, price_low, price_volume, price_open

print("⏳ Mengunduh data harga historis IDX...")
try:
    price_close, price_high, price_low, price_volume, price_open = download_batch_optimized(idx_tickers)
    n_success = len([t for t in idx_tickers if t in price_close.columns])
    print(f"✅ Data harga berhasil diunduh: {n_success}/{len(idx_tickers)}")
    print(f"✅ Data volume tersedia untuk {len(price_volume.columns)} saham\n")
except Exception as e:
    print(f"❌ ERROR downloading data: {e}")
    sys.exit(1)

# Macro (minyak)
print("⏳ Mengunduh data macro (minyak)...")
oil_change_5d = 0.0
try:
    oil_data = yf.download("CL=F", period="1mo", progress=False, auto_adjust=True)
    if isinstance(oil_data, pd.DataFrame) and not oil_data.empty:
        if isinstance(oil_data.columns, pd.MultiIndex):
            try:
                oil_data = oil_data.xs("CL=F", level=1, axis=1)
            except KeyError:
                oil_data = oil_data.droplevel(1, axis=1)
        if "Close" in oil_data.columns:
            oil_raw = oil_data["Close"]
        else:
            oil_raw = oil_data.iloc[:, 0] if oil_data.shape[1] > 0 else pd.Series(dtype=float)
        
        if len(oil_raw) > 0 and not oil_raw.isna().all():
            _oil_mean = oil_raw.pct_change().tail(5).mean()
            oil_change_5d = float(_oil_mean * 100) if not pd.isna(_oil_mean) else 0.0
        else:
            print("   ⚠️ Data minyak kosong atau semua NaN")
    else:
        print("   ⚠️ Gagal mengunduh data minyak")
except Exception as e:
    print(f"   ⚠️ Gagal download minyak: {e}")

# ── [2c] USD/IDR — Nilai tukar Rupiah sebagai macro variable ─────────────────
# Rupiah adalah salah satu driver terkuat untuk saham IDX karena:
#   - Rupiah melemah → saham eksportir (komoditas, CPO) diuntungkan
#   - Rupiah melemah → saham dengan utang USD (property, infra) tertekan
#   - Rupiah melemah tajam (>1% dalam 5 hari) = sinyal risk-off → semua saham tertekan
#
# Variabel yang dihasilkan:
#   usdidr_rate      : kurs USD/IDR saat ini (misal: 16.250)
#   usdidr_change_5d : perubahan 5 hari dalam persen
#                      positif = Rupiah MELEMAH (USD lebih mahal)
#                      negatif = Rupiah MENGUAT
#   idr_pressure     : True jika Rupiah melemah > 1% dalam 5 hari (sinyal waspada)
#   idr_regime       : "WEAK" / "STABLE" / "STRONG"
#
# Threshold:
#   Melemah > +1.5% dalam 5 hari → IDR_REGIME = "WEAK"  → naikkan threshold sinyal
#   Melemah > +3.0% dalam 5 hari → idr_pressure = True  → override macro_ok = False
#   Menguat  > -1.0% dalam 5 hari → IDR_REGIME = "STRONG" → sedikit longgarkan threshold

usdidr_rate      = 0.0
usdidr_change_5d = 0.0
idr_pressure     = False
idr_regime       = "STABLE"

print("⏳ Mengunduh data USD/IDR [2c]...")
try:
    _usd_raw = yf.download("IDR=X", period="1mo", progress=False, auto_adjust=True)
    if isinstance(_usd_raw, pd.DataFrame) and not _usd_raw.empty:
        # Handle MultiIndex
        if isinstance(_usd_raw.columns, pd.MultiIndex):
            try:    _usd_raw = _usd_raw.xs("IDR=X", level=1, axis=1)
            except: _usd_raw = _usd_raw.droplevel(1, axis=1)

        _usd_close = _usd_raw["Close"] if "Close" in _usd_raw.columns \
                     else _usd_raw.iloc[:, 0]
        _usd_close = _usd_close.dropna()

        if len(_usd_close) >= 6:
            usdidr_rate      = float(_usd_close.iloc[-1])
            _usd_ret5        = _usd_close.pct_change(5).iloc[-1]
            usdidr_change_5d = float(_usd_ret5 * 100) if not pd.isna(_usd_ret5) else 0.0

            # Tentukan IDR regime
            if usdidr_change_5d > 1.5:
                idr_regime = "WEAK"       # Rupiah melemah signifikan
            elif usdidr_change_5d < -1.0:
                idr_regime = "STRONG"     # Rupiah menguat
            else:
                idr_regime = "STABLE"

            # Pressure flag: Rupiah melemah > 3% dalam 5 hari = waspada
            idr_pressure = usdidr_change_5d > 3.0

            print(f"   ✅ USD/IDR     : Rp{usdidr_rate:,.0f}")
            print(f"   USD/IDR 5d    : {usdidr_change_5d:+.2f}% "
                  f"({'Rupiah MELEMAH ⚠️' if usdidr_change_5d > 0 else 'Rupiah MENGUAT ✅'})")
            print(f"   IDR Regime    : {idr_regime}"
                  f"{' 🚨 PRESSURE TINGGI' if idr_pressure else ''}")
        else:
            print("   ⚠️ Data USD/IDR terlalu sedikit — IDR regime diabaikan")
    else:
        print("   ⚠️ Gagal mengunduh USD/IDR — IDR regime diabaikan")
except Exception as e:
    print(f"   ⚠️ Gagal download USD/IDR: {e} — IDR regime diabaikan")
# ─────────────────────────────────────────────────────────────────────────────

BI_RATE = 4.75
MACRO_OK = True

print(f"\n🔍 MACRO STATUS:")
print(f"   BI Rate       : {BI_RATE}%")
print(f"   Oil 5d change : {oil_change_5d:.2f}%")
print(f"   USD/IDR       : Rp{usdidr_rate:,.0f} ({usdidr_change_5d:+.2f}% / 5d) [{idr_regime}]")
print(f"   IDR Pressure  : {'🚨 YA — threshold sinyal dinaikkan otomatis' if idr_pressure else '✅ TIDAK'}")
print(f"   MACRO FILTER  : {'AKTIF' if USE_MACRO_FILTER else 'NON-AKTIF (mode Full IDX)'}\n")

# ── [3c] Download IHSG (^JKSE) untuk Relative Strength calculation ──────────
# ihsg_close disimpan sebagai Series global dan dipakai saat generate sinyal
# per saham. Return 5 hari IHSG menjadi pembanding untuk setiap saham.
#
# Analogi: seperti menilai pelari bukan hanya dari waktu larinya, tapi
# apakah ia lebih cepat dari rata-rata seluruh peserta lomba hari itu.
# Saham yang naik 2% saat IHSG naik 1% = RS=2.0 (outperform).
# Saham yang naik 1% saat IHSG naik 3% = RS=0.33 (underperform).
ihsg_close    = pd.Series(dtype=float)   # fallback default
ihsg_ret_5d   = 0.0                      # return IHSG 5 hari terakhir

print("⏳ Mengunduh data IHSG (^JKSE) untuk Relative Strength...")
try:
    _ihsg_raw = yf.download("^JKSE", period="6mo", progress=False, auto_adjust=True)
    if isinstance(_ihsg_raw, pd.DataFrame) and not _ihsg_raw.empty:
        # Handle MultiIndex jika ada
        if isinstance(_ihsg_raw.columns, pd.MultiIndex):
            try:
                _ihsg_raw = _ihsg_raw.xs("^JKSE", level=1, axis=1)
            except KeyError:
                _ihsg_raw = _ihsg_raw.droplevel(1, axis=1)
        if "Close" in _ihsg_raw.columns:
            ihsg_close = _ihsg_raw["Close"].dropna()
        elif _ihsg_raw.shape[1] > 0:
            ihsg_close = _ihsg_raw.iloc[:, 0].dropna()

        if len(ihsg_close) >= 6:
            # Return 5 hari terakhir IHSG (scalar, untuk referensi display)
            ihsg_ret_5d = float(ihsg_close.pct_change(5).iloc[-1]) * 100
            print(f"   ✅ IHSG berhasil diunduh: {len(ihsg_close)} hari")
            print(f"   IHSG return 5d : {ihsg_ret_5d:+.2f}%")
        else:
            print("   ⚠️ Data IHSG terlalu sedikit, RS_Score akan di-skip")
    else:
        print("   ⚠️ Gagal mengunduh IHSG — RS_Score akan di-skip")
except Exception as e:
    print(f"   ⚠️ Error download IHSG: {e} — RS_Score akan di-skip")
# ─────────────────────────────────────────────────────────────────────────────

# =============================================================
# Fundamental
# =============================================================
def safe_convert_to_float(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        try:
            if np.isnan(float(value)):
                return None
        except:
            return None
        return float(value)
    if isinstance(value, str):
        value_clean = value.strip().lower()
        if value_clean in ['infinity', 'inf', 'nan', 'n/a', '-', '']:
            return None
        try:
            return float(value)
        except ValueError:
            return None
    return None

def get_fundamental_data(ticker):
    try:
        time.sleep(0.05)
        info = yf.Ticker(ticker).info
        return {
            "trailingPE": safe_convert_to_float(info.get("trailingPE")),
            "priceToBook": safe_convert_to_float(info.get("priceToBook")),
            "earningsGrowth": safe_convert_to_float(info.get("earningsGrowth")),
            "returnOnEquity": safe_convert_to_float(info.get("returnOnEquity")),
            "debtToEquity": safe_convert_to_float(info.get("debtToEquity")),
            "pegRatio": safe_convert_to_float(info.get("pegRatio")),
            "profitMargins": safe_convert_to_float(info.get("profitMargins")),
            "operatingMargins": safe_convert_to_float(info.get("operatingMargins"))
        }
    except Exception:
        return {}

def is_fundamentally_attractive(fund):
    if not fund:
        return False

    pe = safe_convert_to_float(fund.get("trailingPE"))
    pbv = safe_convert_to_float(fund.get("priceToBook"))
    growth = safe_convert_to_float(fund.get("earningsGrowth"))
    roe = safe_convert_to_float(fund.get("returnOnEquity"))

    pe_ok = pe is not None and 0 < pe < 30
    pbv_ok = pbv is not None and 0 < pbv < 3.5
    growth_ok = growth is not None and 0.02 < growth < 5
    roe_ok = roe is not None and roe > 0.05

    dte = safe_convert_to_float(fund.get("debtToEquity"))
    peg = safe_convert_to_float(fund.get("pegRatio"))
    pm = safe_convert_to_float(fund.get("profitMargins"))

    dte_ok = dte is not None and dte < 100
    peg_ok = peg is not None and 0 < peg < 1.5
    pm_ok = pm is not None and pm > 0.05

    score = sum([pe_ok, pbv_ok, growth_ok, roe_ok, dte_ok, peg_ok, pm_ok])
    return score >= 3

available_tickers = [t for t in idx_tickers if t in price_close.columns]
print(f"⏳ Mengunduh data fundamental untuk {len(available_tickers)} saham...")
fundamental_data = {}
failed_count = 0

for i, ticker in enumerate(available_tickers, 1):
    try:
        fund = get_fundamental_data(ticker)
        fundamental_data[ticker] = fund
        if not fund or all(v is None for v in fund.values()):
            failed_count += 1
        if i % 20 == 0 or i == len(available_tickers):
            print(f"   ✓ {i}/{len(available_tickers)} selesai (failed: {failed_count})")
        time.sleep(0.1)
    except Exception:
        fundamental_data[ticker] = {}
        failed_count += 1
        if i % 20 == 0:
            print(f"   ✓ {i}/{len(available_tickers)} selesai (failed: {failed_count})")
        
print(f"✅ Data fundamental selesai\n")

# =============================================================
# ALADDIN ENGINE: Signal + Backtest
# =============================================================
print("=" * 78)
print("  🔧 PHASE 1: ALADDIN ENGINE (Signal + Backtest) - HYBRID v37.1.5")
print("  Menggunakan Multi-Factor Signal + Enhanced Entry/Exit Logic + Adaptive Market Regime")
print("=" * 78)

backtest_results = {}
processed_count = 0
total_tickers = len(available_tickers)

for idx_i, ticker in enumerate(available_tickers, 1):
    if idx_i % 10 == 0:
        print(f"   [{idx_i}/{total_tickers}] memproses {ticker}...")

    try:
        df = pd.DataFrame(index=price_close.index)
        df["Close"]  = price_close[ticker]
        df["High"]   = price_high[ticker]  if ticker in price_high.columns  else price_close[ticker]
        df["Low"]    = price_low[ticker]   if ticker in price_low.columns   else price_close[ticker]
        df["Volume"] = price_volume[ticker] if ticker in price_volume.columns else np.nan
        # [3a] Open kini tersedia dari download
        df["Open"]   = price_open[ticker]  if ticker in price_open.columns  else price_close[ticker]

        df = df.dropna(subset=["Close"])
        if len(df) < 200:
            continue

        # SIGNAL GENERATION
        df["MA5"]   = df["Close"].rolling(5).mean().shift(1)
        df["MA20"]  = df["Close"].rolling(20).mean().shift(1)
        df["MA50"]  = df["Close"].rolling(50).mean().shift(1)
        df["MA200"] = df["Close"].rolling(200).mean().shift(1)

        delta = df["Close"].diff()
        gain = delta.where(delta > 0, 0).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        df["RSI"] = (100 - 100 / (1 + rs)).shift(1)

        # ── VOL_20 & LOW_VOL — harus dihitung PERTAMA sebelum ROC_3 dan indikator lain
        # yang bergantung pada vol_20 sebagai skala normalisasi.
        # BUG 37.1.10: vol_20 dihitung SETELAH ROC_3 → KeyError 'vol_20' pada 561 saham.
        returns_vol      = df["Close"].pct_change()
        df["vol_20"]     = returns_vol.rolling(20).std().shift(1)
        df["vol_100_avg"]= df["vol_20"].rolling(100).mean().shift(1)
        df["low_vol"]    = (df["vol_20"] < df["vol_100_avg"]).fillna(False)

        # [2a] ROC_3 — gantikan MACD sebagai momentum jangka pendek
        # MACD (EMA 12/26) butuh 26 hari data dan masih lagging untuk 1-hari holding.
        # ROC_3 = return 3 hari terakhir — langsung mencerminkan momentum terkini.
        # Analoginya: MACD seperti melihat spidometer rata-rata 2 minggu lalu;
        # ROC_3 seperti melihat spidometer 3 detik lalu — jauh lebih relevan saat ini.
        df["ROC_3"] = df["Close"].pct_change(3).shift(1)
        # Normalisasi ROC_3 ke [0,1] menggunakan vol_20 sebagai skala
        _roc_cap = (df["vol_20"] * 3).replace(0, np.nan)
        df["ROC_3_Score"] = (df["ROC_3"].clip(0, None) / _roc_cap).clip(0, 1.0).fillna(0)

        # [2b] GAP OVERNIGHT — minat beli di pembukaan
        # Gap = (Open_hari_ini - Close_kemarin) / Close_kemarin
        # Gap positif konsisten = ada demand di pembukaan → sinyal kuat untuk intraday.
        # Dihitung rolling mean 3 hari untuk mengurangi noise satu-hari.
        # Analoginya: toko yang ramai di jam buka pagi kemungkinan ramai sepanjang hari.
        daily_gap = (df["Open"] - df["Close"].shift(1)) / df["Close"].shift(1).replace(0, np.nan)
        df["Gap_Overnight"]     = daily_gap.shift(1)           # gap kemarin (no lookahead)
        df["Gap_3d_Mean"]       = daily_gap.rolling(3).mean().shift(1)  # rata-rata 3 hari
        # Normalisasi: clip [-0.03, 0.03] → rescale ke [0,1]
        df["Gap_Score"] = ((df["Gap_3d_Mean"].clip(-0.03, 0.03) + 0.03) / 0.06).fillna(0.5)

        # [2d] VOL_ROC_3 — akselerasi volume, bukan hanya level
        # Volume_Confirmation saat ini binary (ya/tidak vs MA20).
        # Vol_ROC_3 = rata-rata volume 3 hari / MA20 — menangkap tren volume yang naik.
        # Analoginya: kota yang penduduknya tumbuh 10% 3 tahun berturut-turut lebih
        # menarik dari kota yang sesaat saja padat.
        vol_ma20 = df["Volume"].rolling(20).mean().shift(1)
        vol_3d   = df["Volume"].rolling(3).mean().shift(1)
        _vol_roc_raw = (vol_3d / vol_ma20.replace(0, np.nan)).fillna(1.0)
        # Normalisasi: ratio 1.0 = netral → score 0.5; ratio 2.0+ = score 1.0
        df["Vol_ROC_3_Score"] = ((_vol_roc_raw.clip(0.5, 2.5) - 0.5) / 2.0).fillna(0.5)

        # [3d] HIGH-LOW SPREAD FILTER — proxy bid-ask untuk likuiditas intraday
        # (High-Low)/Close mengukur seberapa lebar range harian relatif harga.
        # Nilai >5% = spread terlalu lebar → saham mahal untuk dieksekusi intraday.
        # Ini disimpan sebagai flag (bukan score) — dipakai sebagai hard filter di Phase 2.
        hl_spread = ((df["High"] - df["Low"]) / df["Close"].replace(0, np.nan)).shift(1)
        df["HL_Spread_Pct"]  = hl_spread
        df["HL_Spread_Wide"] = (hl_spread > 0.05).fillna(False)  # True = spread lebar = berbahaya

        prev_close = df["Close"].shift(1)
        tr = pd.concat([
            df["High"] - df["Low"],
            (df["High"] - prev_close).abs(),
            (df["Low"] - prev_close).abs()
        ], axis=1).max(axis=1)
        df["ATR"] = tr.rolling(14).mean().shift(1)

        # ── [3b] CANDLE PATTERN VARIABLES ───────────────────────────────────
        # Body candle dihitung dari Open dan Close hari sebelumnya (shift(1)).
        # Ini memberi sinyal arah dan kekuatan pergerakan kemarin sebagai
        # prediktor untuk hari ini — tanpa look-ahead bias.
        #
        # Logika: candle bullish besar (Close >> Open) menunjukkan tekanan
        # beli dominan. Jika dikonfirmasi volume, probabilitas lanjutan naik
        # esok hari lebih tinggi. Analoginya: jika kemarin banyak orang
        # antusias beli sampai tutup tinggi, besok pagi biasanya masih ada sisa momentum.

        prev_open  = df["Open"].shift(1)
        prev_close = df["Close"].shift(1)   # sudah ada, alias untuk kejelasan

        # Ukuran body (selisih absolut Close-Open kemarin)
        df["Candle_Body"]     = (df["Close"].shift(1) - df["Open"].shift(1))
        # Body dalam persen harga — normalisasi antar saham
        df["Candle_Body_Pct"] = df["Candle_Body"] / df["Open"].shift(1).replace(0, np.nan)
        # Arah candle: +1 bullish, -1 bearish, 0 doji
        df["Candle_Dir"]      = np.sign(df["Candle_Body"])

        # Relative body strength: body / ATR → seberapa besar body vs volatilitas normal
        # Score 0-1: body ≥ 1× ATR → score 1.0 (candle kuat)
        _atr_ref = df["ATR"].replace(0, np.nan)
        df["Candle_Strength"] = (df["Candle_Body"].abs() / _atr_ref).clip(0, 1.0).fillna(0)

        # Candle Score untuk composite signal:
        # bullish candle kuat (dir=+1, strength tinggi) → skor tinggi
        # bearish candle → skor rendah (atau negatif → clip ke 0)
        df["Candle_Score"] = (df["Candle_Dir"] * df["Candle_Strength"]).clip(0, 1.0).fillna(0)
        # ────────────────────────────────────────────────────────────────────

        # MARKET REGIME DETECTION (vol_20 sudah tersedia dari atas)
        if USE_ADAPTIVE_REGIME:
            regime = get_market_regime(df, ticker)
            adaptive_params = get_adaptive_parameters(regime)
        else:
            regime = "NORMAL"
            adaptive_params = get_adaptive_parameters("NORMAL")
        
        rsi_min = adaptive_params.get("rsi_min", 45)
        rsi_max = adaptive_params.get("rsi_max", 75)
        volume_ratio_threshold = adaptive_params.get("volume_ratio_threshold", 1.5)
        momentum_threshold = adaptive_params.get("momentum_threshold", 0.006)
        signal_threshold = adaptive_params.get("signal_threshold", THRESHOLD["NORMAL"])
        # [2c] Jika Rupiah tertekan (melemah >3% dalam 5 hari), naikkan threshold 0.05
        # Hanya sinyal kuat yang layak dieksekusi saat kondisi macro memburuk
        if idr_pressure:
            signal_threshold = min(signal_threshold + 0.05, 0.85)
        
        # SIGNAL COMPONENTS
        # [BUG 3 FIX] MA5/MA20/MA50 sudah di-shift(1) saat dibuat,
        # hapus .shift(1) tambahan di sini agar tidak double-shift
        df["Trend_Strength"] = (
            (df["Close"] > df["MA5"]) * 1.0 +
            (df["Close"] > df["MA20"]) * 1.5 +
            (df["MA5"] > df["MA20"]) * 1.0 +
            (df["MA20"] > df["MA50"]) * 0.5
        )
        df["Trend_Strength_Norm"] = (df["Trend_Strength"] / 4.0).clip(0, 1)

        df["Volume_Ratio"] = df["Volume"].shift(1) / df["Volume"].rolling(20).mean().shift(1)
        df["Volume_Confirmation"] = (df["Volume_Ratio"] > volume_ratio_threshold).astype(float)

        # [FT-4 FIX] RSI Scoring asimetris mengikuti rsi_min/rsi_max dari adaptive regime.
        # Sweet spot = tengah antara rsi_min dan rsi_max (bukan hardcode 52/68).
        # Ini memastikan fungsi konsisten di semua regime (BULLISH, BEARISH, HIGH_VOL, dll).
        rsi_sweet_low  = rsi_min + (rsi_max - rsi_min) * 0.35   # 35% dari range
        rsi_sweet_high = rsi_min + (rsi_max - rsi_min) * 0.70   # 70% dari range
        rsi_danger     = rsi_max                                  # batas atas regime

        def _rsi_asymmetric(rsi_val):
            """Asimetris: naik gradual ke sweet_high, turun cepat menuju danger."""
            if pd.isna(rsi_val) or rsi_val < rsi_min:
                return 0.0
            elif rsi_val < rsi_sweet_low:
                return (rsi_val - rsi_min) / max(rsi_sweet_low - rsi_min, 1e-6) * 0.6
            elif rsi_val <= rsi_sweet_high:
                return 0.6 + 0.4 * (rsi_val - rsi_sweet_low) / max(rsi_sweet_high - rsi_sweet_low, 1e-6)
            elif rsi_val < rsi_danger:
                return 1.0 - (rsi_val - rsi_sweet_high) / max(rsi_danger - rsi_sweet_high, 1e-6)
            else:
                return 0.0

        df["RSI_Score"] = df["RSI"].apply(_rsi_asymmetric)

        # [FT-5] Momentum dinormalisasi terhadap vol_20 saham sendiri.
        # Tanpa normalisasi, saham banking (vol rendah) hampir tidak pernah
        # memenuhi threshold yang sama dengan saham mining (vol tinggi).
        # Setelah normalisasi: momentum 0.5% pada saham vol-0.5% = score sama
        # dengan momentum 2% pada saham vol-2%.
        df["Momentum_Raw"]    = df["Close"].pct_change(5).shift(1)
        df["Momentum_Strong"] = df["Momentum_Raw"] > momentum_threshold

        # [FT-5 + 2a] Momentum_Score = kombinasi ROC_5 (normalized) dan ROC_3_Score
        # ROC_3 [2a] sudah dihitung di atas — lebih responsif untuk intraday
        # Blending: 60% ROC_3 (jangka pendek, forward-looking) + 40% ROC_5 (konteks)
        _vol_ref    = df["vol_20"].replace(0, np.nan)
        _mom5_score = (df["Momentum_Raw"].clip(0, None) / (_vol_ref * 2).replace(0, np.nan)).clip(0, 1.0).fillna(0)
        df["Momentum_Score"] = (0.60 * df["ROC_3_Score"] + 0.40 * _mom5_score).clip(0, 1.0)

        df["Low_Vol_Bonus"] = df["low_vol"].astype(float)

        # ── [3c] RELATIVE STRENGTH vs IHSG ──────────────────────────────────
        # RS mengukur apakah saham lebih kuat dari pasar secara keseluruhan.
        # Formula rolling: RS = return_5d_saham / |return_5d_IHSG|
        #
        #   RS > 1.0 → outperform IHSG → potensi leader besok
        #   RS < 1.0 → underperform  → saham ikut-ikutan pasar saja
        #   RS < 0   → turun saat IHSG naik → sinyal negatif kuat
        #
        # Normalisasi ke [0,1]: clip RS ke [-2,4] → shift +2 → bagi 6
        #   RS=-2 (sangat underperform) → score=0.0
        #   RS= 1 (sama dengan IHSG)   → score=0.5
        #   RS= 4 (outperform 4×)      → score=1.0
        #
        # Analogi: seperti menilai pelari bukan hanya dari waktunya,
        # tapi apakah ia lebih cepat dari rata-rata peserta lomba hari itu.
        try:
            if len(ihsg_close) >= 6:
                ihsg_aligned = ihsg_close.reindex(df.index, method="ffill")
                ihsg_ret5    = ihsg_aligned.pct_change(5).shift(1)
                stock_ret5   = df["Close"].pct_change(5).shift(1)

                # Hindari pembagian nol — fallback ke benchmark flat 1%
                _denom = ihsg_ret5.abs().replace(0, np.nan)
                rs_raw = stock_ret5 / _denom
                rs_raw = rs_raw.where(_denom.notna(), stock_ret5 / 0.01)

                df["RS_Score"] = ((rs_raw.clip(-2, 4) + 2) / 6).fillna(0.5)
            else:
                df["RS_Score"] = 0.5   # netral jika IHSG tidak tersedia
        except Exception:
            df["RS_Score"] = 0.5
        # ────────────────────────────────────────────────────────────────────

        # COMPOSITE SIGNAL SCORE — 10 faktor [37.4.0]
        # Sector_RS diambil dari dict global sector_rs_scores yang diisi setelah Phase 1
        _sector = get_sector(ticker)
        _sector_rs_val = sector_rs_scores.get(_sector, 0.5)  # default netral

        df["Signal_Score"] = (
            COMPOSITE_WEIGHTS["trend"]         * df["Trend_Strength_Norm"] +
            COMPOSITE_WEIGHTS["volume"]        * df["Volume_Confirmation"] +
            COMPOSITE_WEIGHTS["rsi"]           * df["RSI_Score"] +
            COMPOSITE_WEIGHTS["momentum"]      * df["Momentum_Score"] +      # [2a] ROC_3 inside
            COMPOSITE_WEIGHTS["low_vol"]       * df["Low_Vol_Bonus"] +
            COMPOSITE_WEIGHTS["candle"]        * df["Candle_Score"] +        # [3b]
            COMPOSITE_WEIGHTS["rs_ihsg"]       * df["RS_Score"] +            # [3c]
            COMPOSITE_WEIGHTS["gap_overnight"] * df["Gap_Score"] +           # [2b]
            COMPOSITE_WEIGHTS["vol_roc"]       * df["Vol_ROC_3_Score"] +     # [2d]
            COMPOSITE_WEIGHTS["sector_rs"]     * float(_sector_rs_val)       # [3e]
        )

        # SIGNAL GENERATION
        # [FT-1 FIX] low_vol TIDAK lagi syarat wajib di buy_cond.
        # FT-1 sudah menurunkan bobot low_vol ke 0.05 (jadi bonus kecil di score).
        # Mewajibkan low_vol=True di sini kontradiksi dengan filosofi FT-1
        # dan menyebabkan semua saham aktif (vol tinggi) tidak pernah masuk BUY.
        buy_cond = (
            (df["Signal_Score"] >= signal_threshold) &
            df["Momentum_Strong"] &
            (df["Volume_Confirmation"] > 0)
        ).fillna(False)

        # [BUG 3/5 FIX] sell_cond juga hapus double-shift: RSI & MA5 sudah shift(1)
        # [S1] Sell hanya trend lemah + RSI ekstrem
        # Momentum/MA5 tidak lagi memaksa SELL (mengurangi exit SIGNAL berlebih)
        if regime == "HIGH_VOL":
            sell_cond = (
                (df["Trend_Strength"] < 0.5) |
                (df["RSI"] > rsi_max)
            ).fillna(False)
        else:
            sell_cond = (
                (df["Trend_Strength"] < 0.5) |
                (df["RSI"] > 82)
            ).fillna(False)

        fund_ok = is_fundamentally_attractive(fundamental_data.get(ticker, {}))
        # [BUG 2 FIX] macro_ok menggunakan USE_MACRO_FILTER dan oil_change_5d
        # [2c] Tambah IDR pressure — jika Rupiah melemah ekstrem (>3%), macro_ok = False
        macro_ok = (not USE_MACRO_FILTER) or (
            oil_change_5d > OIL_THRESHOLD and not idr_pressure
        )

        df["Signal"] = np.where(
            buy_cond & bool(macro_ok) & bool(adaptive_params.get("allow_entry", True)) &
            (bool(fund_ok) if "FUNDAMENTAL_MODE" in dir() and FUNDAMENTAL_MODE == "strict" else True),

            "BUY",
            np.where(sell_cond, "SELL", "HOLD")
        )

        # BACKTEST
        timeframes = split_timeframes(df)
        
        prior_sharpe = np.nan
        if "3Y" in timeframes and len(timeframes["3Y"]) >= 50:
            tf_df = timeframes["3Y"].copy()
            if "Signal" not in tf_df.columns:
                tf_df["Signal"] = "HOLD"
            try:
                _baseline = run_backtest_intraday(tf_df, prior_sharpe=np.nan, adaptive_params=adaptive_params)
                prior_sharpe = _baseline.get("sharpe", np.nan)
                if isinstance(prior_sharpe, float) and (np.isnan(prior_sharpe) or prior_sharpe == 0):
                    prior_sharpe = np.nan
            except Exception:
                prior_sharpe = np.nan

        tf_results = {}
        for tf_name, tf_df in timeframes.items():
            if len(tf_df) < 50:
                continue
            if "Signal" not in tf_df.columns:
                tf_df["Signal"] = "HOLD"
            try:
                tf_results[tf_name] = run_backtest_intraday(tf_df, prior_sharpe=prior_sharpe, adaptive_params=adaptive_params)
            except Exception:
                continue

        agg_result = aggregate_multi_tf(tf_results)

        # [BUG 11 FIX] avg_holding_days diambil dari tf_results["3Y"] agar tidak hilang setelah aggregate
        _avg_hold = tf_results.get("3Y", {}).get("avg_holding_days", 0)
        if _avg_hold == 0 and tf_results:
            # fallback ke TF pertama yang tersedia
            for _tf in ["1Y", "3M"]:
                _avg_hold = tf_results.get(_tf, {}).get("avg_holding_days", 0)
                if _avg_hold != 0:
                    break

        backtest_results[ticker] = {
            **agg_result,
            "tf_detail": tf_results,
            "df": df,
            "momentum_score": calculate_momentum_score(df),
            "last_price": float(df["Close"].iloc[-1]) if not pd.isna(df["Close"].iloc[-1]) else 0,
            "atr": float(df["ATR"].iloc[-1]) if "ATR" in df.columns and len(df) > 0 and not pd.isna(df["ATR"].iloc[-1]) else None,
            "rsi": float(df["RSI"].iloc[-1]) if "RSI" in df.columns and len(df) > 0 and not pd.isna(df["RSI"].iloc[-1]) else None,
            "signal_score": float(df["Signal_Score"].iloc[-1]) if len(df) > 0 and not pd.isna(df["Signal_Score"].iloc[-1]) else 0,
            "market_regime": regime,
            # [3c] RS_Score last value
            "rs_score": float(df["RS_Score"].iloc[-1]) if "RS_Score" in df.columns and len(df) > 0 and not pd.isna(df["RS_Score"].iloc[-1]) else 0.5,
            # [3d] HL spread flag — True jika spread terlalu lebar untuk intraday
            "hl_spread_wide": bool(df["HL_Spread_Wide"].iloc[-1]) if "HL_Spread_Wide" in df.columns and len(df) > 0 else False,
            # [2b] Gap score terakhir
            "gap_score": float(df["Gap_Score"].iloc[-1]) if "Gap_Score" in df.columns and len(df) > 0 and not pd.isna(df["Gap_Score"].iloc[-1]) else 0.5,
            # [3e] Sektor untuk Sector_RS lookup
            "sector": get_sector(ticker),
            # [TQG+UTD] Uptrend detection dan quality tier — dipakai di Phase 4
            "uptrend_result": detect_daily_uptrend(df, mode=UPTREND_MODE),
            # [BUG 10 FIX] trend_strength tidak disimpan sebelumnya → selalu 0 di Phase 4
            "trend_strength": float(df["Trend_Strength"].iloc[-1]) if "Trend_Strength" in df.columns and len(df) > 0 and not pd.isna(df["Trend_Strength"].iloc[-1]) else 0.0,
            # [BUG 11 FIX] avg_holding_days dari backtest tf, tidak hilang di aggregate
            "avg_holding_days": float(_avg_hold) if _avg_hold is not None else 0.0,
        }
        processed_count += 1
        
    except Exception as e:
        print(f"   ⚠️ Error processing {ticker}: {str(e)[:100]}")
        continue

print(f"✅ Aladdin Engine selesai: {processed_count} saham berhasil di-backtest\n")

# ── [3e] SECTOR_RS CALCULATOR — dihitung setelah semua backtest selesai ──────
# Setelah semua 561 saham diproses, kita punya return per saham.
# Hitung rata-rata return 5 hari per sektor, bandingkan dengan rata-rata IHSG.
# Sektor yang outperform IHSG mendapat sector_rs_scores > 0.5.
#
# Analoginya: kalau sektor energi rata-rata naik 2% sementara IHSG naik 0.5%,
# saham energi apapun mendapat bonus kecil di Signal_Score karena "angin sektoral" bagus.
print("⏳ Menghitung Sector Relative Strength [3e]...")
try:
    sector_ret_map = {}   # {sektor: [list return_5d saham di sektor itu]}
    for tkr, res in backtest_results.items():
        _sec   = res.get("sector", "OTHER")
        _df_s  = res.get("df")
        if _df_s is not None and "Close" in _df_s.columns and len(_df_s) >= 6:
            _ret5 = float(_df_s["Close"].pct_change(5).iloc[-1])
            if not np.isnan(_ret5):
                sector_ret_map.setdefault(_sec, []).append(_ret5)

    # Rata-rata return IHSG 5 hari (scalar, sudah punya dari download)
    _ihsg_ret_ref = ihsg_ret_5d / 100.0 if abs(ihsg_ret_5d) > 0 else 0.005

    # Hitung RS per sektor, normalisasi ke [0,1]
    for sec, rets in sector_ret_map.items():
        if rets:
            sec_mean = np.mean(rets)
            # RS = return sektor / |return IHSG|, clip dan rescale
            _denom = abs(_ihsg_ret_ref) if abs(_ihsg_ret_ref) > 0.001 else 0.001
            rs_raw = sec_mean / _denom
            sector_rs_scores[sec] = float(np.clip((rs_raw + 2) / 6, 0, 1))

    print(f"   ✅ Sector RS dihitung untuk {len(sector_rs_scores)} sektor")
    for s, v in sorted(sector_rs_scores.items(), key=lambda x: -x[1]):
        bar = "█" * int(v * 20)
        print(f"   {s:<12} {bar:<20} {v:.3f}")
except Exception as e:
    print(f"   ⚠️ Sector RS error: {e} — semua sektor mendapat score 0.5")
    sector_rs_scores = {}
# ─────────────────────────────────────────────────────────────────────────────

# =============================================================
# CROSS-SECTIONAL RANKING
# =============================================================
def add_cross_sectional_ranking(backtest_results):
    data = []
    for ticker, res in backtest_results.items():
        row = {
            "ticker": ticker, "return": res.get("return", 0), "sharpe": res.get("sharpe", 0),
            "win_rate": res.get("win_rate", 0), "max_drawdown": res.get("max_drawdown", 0),
            "momentum_score": res.get("momentum_score", 0), "trades": res.get("trades", 0)
        }
        data.append(row)
    
    df = pd.DataFrame(data)
    if df.empty:
        return pd.DataFrame()
    
    df = df.set_index("ticker")

    for col in ["return", "sharpe", "win_rate", "max_drawdown"]:
        if col not in df.columns:
            df[col] = 0

    df["rank_return"] = df["return"].rank(pct=True)
    df["rank_sharpe"] = df["sharpe"].rank(pct=True)
    df["rank_winrate"] = df["win_rate"].rank(pct=True)
    df["rank_momentum"] = df["momentum_score"].rank(pct=True) if "momentum_score" in df.columns else 0.5
    df["rank_drawdown"] = 1 - df["max_drawdown"].rank(pct=True)

    df["cross_score"] = (
        0.30 * df["rank_return"] + 0.25 * df["rank_sharpe"] +
        0.15 * df["rank_winrate"] + 0.20 * df["rank_momentum"] + 0.10 * df["rank_drawdown"]
    )
    return df

def add_timeframe_relative_strength(df, backtest_results):
    if df.empty:
        return df
    
    df_result = df.copy()
    return_3m_list = []
    return_1y_list = []
    
    for ticker in df_result.index:
        res = backtest_results.get(ticker, {})
        tf_detail = res.get("tf_detail", {})
        return_3m = tf_detail.get("3M", {}).get("return", 0)
        return_1y = tf_detail.get("1Y", {}).get("return", 0)
        return_3m_list.append(return_3m)
        return_1y_list.append(return_1y)
    
    df_result["return_3M"] = return_3m_list
    df_result["return_1Y"] = return_1y_list
    
    if df_result["return_3M"].nunique() > 1:
        df_result["rank_3M"] = df_result["return_3M"].rank(pct=True)
    else:
        df_result["rank_3M"] = 0.5
    
    if df_result["return_1Y"].nunique() > 1:
        df_result["rank_1Y"] = df_result["return_1Y"].rank(pct=True)
    else:
        df_result["rank_1Y"] = 0.5
    
    df_result["relative_strength"] = 0.6 * df_result["rank_3M"] + 0.4 * df_result["rank_1Y"]
    return df_result

ranked_df = add_cross_sectional_ranking(backtest_results)

if not ranked_df.empty:
    ranked_df = add_timeframe_relative_strength(ranked_df, backtest_results)
    ranked_df["cross_score"] = (ranked_df["cross_score"] * 0.7 + ranked_df["relative_strength"] * 0.3)
    print(f"✅ Cross-Sectional Ranking selesai: {len(ranked_df)} saham diranking\n")
else:
    print("⚠️ Tidak ada data untuk ranking\n")

# =============================================================
# PHASE 2: FINAL SELECTION
# =============================================================
print("=" * 78)
print("  🔧 PHASE 2: FINAL SELECTION (Hybrid Balanced 37.1.5)")
print("=" * 78)

selection_data = []
for ticker, res in backtest_results.items():
    tf_detail = res.get("tf_detail", {})
    momentum_3m = tf_detail.get("3M", {}).get("return", res.get("return", 0))
    
    df = res.get("df")
    avg_volume = 0
    price = res.get("last_price", 1000)
    if df is not None and "Volume" in df.columns:
        vol_data = df["Volume"].dropna()
        if len(vol_data) >= 60:
            avg_volume = vol_data.tail(60).mean()
        elif len(vol_data) > 0:
            avg_volume = vol_data.mean()
    
    selection_data.append({
        "ticker": ticker, "trades": res.get("trades", 0), "avg_volume": avg_volume,
        "price": price, "momentum_3m": momentum_3m, "sharpe": res.get("sharpe", 0),
        "winrate": res.get("win_rate", 0), "max_drawdown": res.get("max_drawdown", -50),
        "consistency": 0, "return": res.get("return", 0), "signal_score": res.get("signal_score", 0),
        "market_regime": res.get("market_regime", "NORMAL"),
    })

# INITIALIZE selected_stocks HERE - FIX FOR NameError
selected_stocks = []

if selection_data:
    selection_df = pd.DataFrame(selection_data)
    
    if not selection_df.empty and selection_df["trades"].max() > 0:
        max_trades = selection_df["trades"].max()
        selection_df["consistency"] = (selection_df["winrate"] * (selection_df["trades"] / max_trades)) / 100
    
    print(f"\n📊 Running balanced selection on {len(selection_df)} stocks...")
    
    selected_df = select_stocks_balanced(selection_df, fundamental_data, backtest_results)
    
    # HYBRID RELAX LOGIC
    # [BUG B+D FIX] Relax mode bertahap yang makin longgar, bypass hard filter jika perlu
    MIN_STOCKS_TARGET = 8

    def _score_and_rank(df_in, n_top):
        """Hitung skor minimal dan ambil top N — dipakai oleh relax fallback."""
        d = df_in.copy()
        # Pastikan kolom numerik tersedia
        for c, default in [("momentum_3m", 0), ("sharpe", 0), ("winrate", 0),
                            ("max_drawdown", -50), ("signal_score", 0), ("avg_volume", 0)]:
            if c not in d.columns:
                d[c] = default
            d[c] = pd.to_numeric(d[c], errors="coerce").fillna(default)

        def _norm(s):
            mn, mx = s.min(), s.max()
            if mx == mn:
                return pd.Series(0.5, index=s.index)
            return (s - mn) / (mx - mn)

        d["score"] = (
            0.25 * _norm(d["signal_score"]) +
            0.20 * _norm(d["sharpe"]) +
            0.20 * _norm(d["momentum_3m"]) +
            0.15 * _norm(-d["max_drawdown"]) +
            0.10 * _norm(d["winrate"]) +
            0.10 * _norm(d["avg_volume"])
        )
        return d.sort_values("score", ascending=False).head(n_top).copy()

    if selected_df.empty or len(selected_df) < MIN_STOCKS_TARGET:
        current_count = len(selected_df) if not selected_df.empty else 0
        print(f"⚠️ Hanya {current_count} saham lolos (< {MIN_STOCKS_TARGET})")
        print("   → Mengaktifkan Hybrid Relax Mode bertahap...")

        # RELAX 1: ambil top N dari selection_df, score & rank manual, bypass hard filter
        top_n = MIN_STOCKS_TARGET * 3
        score_col = next((c for c in ['score', 'signal_score', 'sharpe', 'return']
                          if c in selection_df.columns), None)

        if score_col and len(selection_df) >= MIN_STOCKS_TARGET:
            df_relaxed = selection_df.nlargest(top_n, score_col).copy()
            print(f"   [Relax 1] Mengambil {top_n} teratas berdasarkan '{score_col}'")
            selected_df_r1 = select_stocks_balanced(df_relaxed, fundamental_data, backtest_results)
            if not selected_df_r1.empty and len(selected_df_r1) >= MIN_STOCKS_TARGET // 2:
                selected_df = selected_df_r1
                print(f"   [Relax 1] Berhasil: {len(selected_df)} saham")
            else:
                selected_df = pd.DataFrame()

        # RELAX 2: score & rank semua saham tanpa hard filter
        if selected_df.empty or len(selected_df) < MIN_STOCKS_TARGET // 2:
            print(f"   [Relax 2] Scoring semua {len(selection_df)} saham tanpa hard filter...")
            selected_df = _score_and_rank(selection_df, MIN_STOCKS_TARGET)
            print(f"   [Relax 2] Mengambil {len(selected_df)} saham teratas")

        # RELAX 3: ultimate fallback — ambil semua backtest_results, score minimal
        if selected_df.empty:
            print("   [Relax 3] Ultimate fallback: semua saham dari backtest_results...")
            all_data = [
                {"ticker": t, "trades": r.get("trades", 0), "avg_volume": 0,
                 "price": r.get("last_price", 100), "momentum_3m": r.get("return", 0),
                 "sharpe": r.get("sharpe", 0), "winrate": r.get("win_rate", 0),
                 "max_drawdown": r.get("max_drawdown", -50), "signal_score": r.get("signal_score", 0)}
                for t, r in backtest_results.items() if r.get("last_price", 0) >= 50
            ]
            if all_data:
                selected_df = _score_and_rank(pd.DataFrame(all_data), MIN_STOCKS_TARGET)
                print(f"   [Relax 3] {len(selected_df)} saham")

    # [BUG A+C FIX] Pastikan kolom 'score' SELALU ada sebelum print
    if not selected_df.empty and "score" not in selected_df.columns:
        selected_df = _score_and_rank(selected_df, len(selected_df))

    
    # [ABS FLOOR] mutlak — setelah relax, sebelum ranking / QUALIFIED BUY
    if not selected_df.empty:
        selected_df = apply_absolute_quality_floor(selected_df, label="post-relax FINAL")
        selected_stocks = selected_df["ticker"].tolist() if "ticker" in selected_df.columns else selected_df.index.astype(str).tolist()
        print(f"🔒 Setelah ABS FLOOR: {len(selected_stocks)} saham lolos ke ranking")

    if not selected_df.empty and "ticker" in selected_df.columns:
        selected_stocks = selected_df["ticker"].tolist()
    elif not selected_df.empty:
        selected_stocks = selected_df.index.astype(str).tolist()
    else:
        selected_stocks = []

    # TIERED QUALITY GATE INTEGRATION — bangun lookup dict dari selected_df
    # qg_tier/penalty/label ada di kolom df, bukan di backtest_results
    selected_tiers    = {}
    selected_penalties = {}
    selected_labels   = {}
    if not selected_df.empty:
        for _, _row in selected_df.iterrows():
            _tkr = _row.get("ticker", "")
            if _tkr:
                selected_tiers[_tkr]     = int(_row.get("qg_tier",    3))
                selected_penalties[_tkr] = float(_row.get("qg_penalty", TIER3_PENALTY))
                selected_labels[_tkr]    = str(_row.get("qg_label",   "T3"))

    print(f"\n✅ HASIL FINAL SELECTION: {len(selected_stocks)} saham")
    
    if len(selected_stocks) > 0:
        print("\n📋 DETAIL SAHAM LOLOS SELEKSI:")
        print(f"{'#':<4} {'Ticker':<10} {'Trades':>6} {'AvgVol':>12} {'Price':>10} {'Sharpe':>8} {'WinRate':>8} {'Score':>8}")
        print(f"{'─'*75}")
        for idx, (i, row) in enumerate(selected_df.iterrows()):
            score_val = row.get("score", 0) if "score" in row.index else 0
            trades_val = row.get("trades", 0)
            avgvol_val = row.get("avg_volume", 0)
            price_val  = row.get("price", 0)
            sharpe_val = row.get("sharpe", 0)
            winrate_val= row.get("winrate", 0)
            print(f"{idx+1:<4} {row['ticker']:<10} {trades_val:>6.0f} {avgvol_val:>12,.0f} {price_val:>10,.0f} "
                  f"{sharpe_val:>8.2f} {winrate_val:>7.1f}% {score_val:>8.4f}")
    else:
        print("   ⚠️ WARNING: Tidak ada saham yang lolos seleksi!")
else:
    print("⚠️ Tidak ada data untuk seleksi (selection_data kosong)")

# =============================================================
# FORECAST ENGINE (Phase 3) dan MONTE CARLO GATEKEEPER
# =============================================================
if len(selected_stocks) > 0:
    print("\n" + "=" * 78)
    print("  🔧 PHASE 3: FORECAST ENGINE (GARCH + Student-t) - Hybrid")
    print("=" * 78)
    print(f"   Menjalankan forecast untuk {len(selected_stocks)} saham terpilih...\n")

    forecast_results = {}
    for ticker in selected_stocks:
        res = backtest_results.get(ticker, {})
        df = res.get("df")
        if df is None or len(df) < 50:
            print(f"   ⚠️ {ticker}: Data tidak cukup untuk forecast")
            forecast_results[ticker] = {
                "error": "Insufficient data", "prob_up": 50, "median_return": 0,
                "range_min": -5, "range_max": 5, "current_price": res.get("last_price", 0),
                "method": "N/A", "momentum_score": 0, "vol_source": "error", "garch_used": False,
                "t_df": 5.0, "std_used": res.get("last_price", 1000) * 0.02
            }
            continue
        forecast = monte_carlo_forecast(df, method="sobol")
        forecast_results[ticker] = forecast
        if forecast.get("error"):
            print(f"   ⚠️ {ticker}: {forecast['error']}")
        else:
            print(f"   ✅ {ticker}: Prob_Up={forecast['prob_up']:.1f}%, Med_Ret={forecast['median_return']:+.2f}%, "
                  f"Range={forecast['range_min']:+.1f}%→{forecast['range_max']:+.1f}% (vol={forecast['vol_source']})")

    print(f"\n✅ Forecast Engine selesai untuk {len([t for t in selected_stocks if t in forecast_results])} saham\n")

    # MONTE CARLO GATEKEEPER
    # [BUG F FIX] Bangun mc_input_df sekaligus agar index sinkron & aman
    sl_list = []
    tp_list = []
    close_list = []
    for ticker in selected_stocks:
        price = backtest_results.get(ticker, {}).get("last_price", 0)
        atr_val = backtest_results.get(ticker, {}).get("atr", None)
        if atr_val is None or atr_val <= 0:
            atr_val = price * 0.02 if price > 0 else 1.0
        close_list.append(price)
        sl_list.append(price - (2 * atr_val))
        tp_list.append(price + (6 * atr_val))

    mc_input_df = pd.DataFrame({
        "Ticker":      selected_stocks,
        "Close":       close_list,
        "Signal":      ["BUY"] * len(selected_stocks),
        "Stop_Loss":   sl_list,
        "Take_Profit": tp_list,
    })

    garch_params = {}
    for ticker in selected_stocks:
        fc = forecast_results.get(ticker, {})
        sigma = fc.get("std_used", 0)
        if sigma == 0 or sigma is None:
            sigma = backtest_results.get(ticker, {}).get("last_price", 1000) * 0.02
        median_return_pct = fc.get("median_return", 0)
        mu = median_return_pct / 100
        garch_params[ticker] = {"mu": mu, "sigma": sigma}
    
    # [BUG 12 FIX] semua saham di selected_stocks harus diproses MC, bukan hanya 10 pertama
    mc_results_df = run_monte_carlo_batch(mc_input_df, garch_params)
    
    if not mc_results_df.empty:
        signal_override = dict(zip(mc_results_df["Ticker"], mc_results_df["Signal_Final"]))
        p_sl_dict = dict(zip(mc_results_df["Ticker"], mc_results_df["P_SL_%"]))
        ev_dict = dict(zip(mc_results_df["Ticker"], mc_results_df["EV_Rp"]))
        mc_decision_dict = dict(zip(mc_results_df["Ticker"], mc_results_df["MC_Decision"]))
    else:
        signal_override = {}
        p_sl_dict = {}
        ev_dict = {}
        mc_decision_dict = {}
    
    # PHASE 4: Ranking dan Rekomendasi
    print("\n" + "=" * 78)
    print("  🔧 PHASE 4: ENHANCED RANKING (Scoring + TOP 10 + MONTE CARLO + HYBRID)")
    print("=" * 78)

    ranking_list = []
    for ticker in selected_stocks:
        res = backtest_results.get(ticker, {})
        fc = forecast_results.get(ticker, {})
        
        mc_signal = signal_override.get(ticker, "BUY")
        mc_p_sl = p_sl_dict.get(ticker, 50.0)
        mc_ev = ev_dict.get(ticker, 0)
        mc_decision = mc_decision_dict.get(ticker, "BUY")
        
        ranking_list.append({
            "Ticker": ticker, "Sharpe": res.get("sharpe", 0), "WinRate": res.get("win_rate", 0),
            "Return": res.get("return", 0), "Trades": res.get("trades", 0), "MaxDD": res.get("max_drawdown", 0),
            "Momentum_Score": res.get("momentum_score", 0), "Prob_Up_%": fc.get("prob_up", 50),
            "Median_Return_%": fc.get("median_return", 0), "Range_Min_%": fc.get("range_min", -5),
            "Range_Max_%": fc.get("range_max", 5), "Current_Price": fc.get("current_price", res.get("last_price", 0)),
            "Vol_Source": fc.get("vol_source", "N/A"), "t_df": fc.get("t_df", 5),
            "P_SL_%": mc_p_sl, "EV_Rp": mc_ev, "MC_Decision": mc_decision, "Signal_MC": mc_signal,
            "Trend_Strength": res.get("trend_strength", 0), "Avg_Holding_Days": res.get("avg_holding_days", 0),
            "Market_Regime": res.get("market_regime", "NORMAL"), "Signal_Score": res.get("signal_score", 0),
            # [3c] RS vs IHSG
            "RS_Score": res.get("rs_score", 0.5),
            # TIERED QUALITY GATE INTEGRATION — ambil dari selected_stocks df
            # qg_tier/penalty/label di-assign oleh select_stocks_balanced,
            # disimpan di kolom df, bukan di backtest_results dict.
            "QG_Tier":    selected_tiers.get(ticker, 3),
            "QG_Penalty": selected_penalties.get(ticker, TIER3_PENALTY),
            "QG_Label":   selected_labels.get(ticker, "T3"),
            # [UTD] uptrend bonus
            "Uptrend_Bonus": res.get("uptrend_result", {}).get("uptrend_bonus", 0.0),
            "Uptrend_Score": res.get("uptrend_result", {}).get("uptrend_score", 0.0),
            "Uptrend_Flag":  res.get("uptrend_result", {}).get("uptrend_flag",  False),
        })

    df_ranking = pd.DataFrame(ranking_list)
    if not df_ranking.empty:
        def norm_col_p4(s):
            s = pd.to_numeric(s, errors="coerce").fillna(0)
            mn, mx = s.min(), s.max()
            if mx == mn:
                return pd.Series(0.5, index=s.index)
            raw = (s - mn) / (mx - mn)
            return raw.clip(0.20, 0.80)

        df_ranking["N_Sharpe"]       = norm_col_p4(df_ranking["Sharpe"])
        df_ranking["N_WinRate"]      = norm_col_p4(df_ranking["WinRate"])
        df_ranking["N_Return"]       = norm_col_p4(df_ranking["Return"])
        df_ranking["N_Prob_Up"]      = norm_col_p4(df_ranking["Prob_Up_%"])
        df_ranking["N_Med_Ret"]      = norm_col_p4(df_ranking["Median_Return_%"])
        df_ranking["N_Trend_Str"]    = norm_col_p4(df_ranking["Trend_Strength"])
        df_ranking["N_Signal_Score"] = norm_col_p4(df_ranking["Signal_Score"])
        # [3c] Normalisasi RS_Score untuk Phase 4 — sudah dalam [0,1], langsung pakai
        df_ranking["N_RS"] = df_ranking["RS_Score"].clip(0, 1).fillna(0.5)

        if df_ranking["P_SL_%"].nunique() > 1:
            df_ranking["N_P_SL"] = 1 - norm_col_p4(df_ranking["P_SL_%"])
        else:
            df_ranking["N_P_SL"] = 0.5

        df_ranking["Regime_Bonus"] = df_ranking["Market_Regime"].apply(
            lambda x: 0.05 if x == "BULLISH" else (0.02 if x == "NORMAL" else (-0.03 if x == "HIGH_VOL" else -0.05)))

        # [FT-3 + 3c + TQG + UTD] Final Ranking Score:
        # Setelah semua faktor dinormalisasi, terapkan penalti tier dan bonus uptrend.
        # Ini dilakukan SETELAH normalisasi agar tidak mengubah skala antar faktor.
        df_ranking["Score"] = (
            df_ranking["N_Signal_Score"] * 0.22 +
            df_ranking["N_Trend_Str"]    * 0.17 +
            df_ranking["N_P_SL"]         * 0.15 +
            df_ranking["N_Prob_Up"]      * 0.12 +
            df_ranking["N_Sharpe"]       * 0.11 +
            df_ranking["N_RS"]           * 0.08 +
            df_ranking["N_WinRate"]      * 0.07 +
            df_ranking["N_Med_Ret"]      * 0.05 +
            df_ranking["N_Return"]       * 0.03 +
            df_ranking["Regime_Bonus"]
        )

        # TIERED QUALITY GATE INTEGRATION — Phase 4 Score adjustment
        # QG_Penalty menyimpan nilai: +0.08 (T1), -0.04 (T2), -0.10 (T3)
        # Tier 1 mendapat BONUS aktif → naik ranking vs hanya "tidak dihukum"
        # Diterapkan SETELAH normalisasi agar tidak mengubah skala faktor lain
        if "QG_Penalty" in df_ranking.columns:
            df_ranking["Score"] += df_ranking["QG_Penalty"].fillna(TIER3_PENALTY)
            # Diagnostik tier distribution di ranking final
            if "QG_Label" in df_ranking.columns:
                tier_counts = df_ranking["QG_Label"].value_counts().to_dict()
                print(f"   Tier distribution: {tier_counts}")

        # [UTD] Uptrend bonus — hanya untuk saham yang lolos detect_daily_uptrend
        # Bonus 0.05–0.09 sesuai UPTREND_MODE (tidak double count dengan composite)
        if "Uptrend_Bonus" in df_ranking.columns:
            df_ranking["Score"] += df_ranking["Uptrend_Bonus"].fillna(0.0)

        print("\n📊 DIAGNOSTIK SCORING PHASE 4:")
        print(f"   Score range: {df_ranking['Score'].min():.4f} – {df_ranking['Score'].max():.4f}")

        df_ranking = df_ranking.sort_values("Score", ascending=False).reset_index(drop=True)
        print(f"✅ Ranking selesai: {len(df_ranking)} saham masuk ranking\n")

        # Output TOP 10
        print("\n" + "=" * 78)
        print("  🚀 TOP 10 - Final Output")
        print("=" * 96)

        top10 = df_ranking.head(min(10, len(df_ranking)))

        print(f"\n{'#':<4} {'Ticker':<10} {'Sharpe':>8} {'WinRate':>8} {'Prob_Up':>8} "
              f"{'Score':>8} {'SignalScore':>12} {'Tier':>5} {'UTD':>4} {'Regime':<10}")
        print(f"{'─'*96}")
        for enum_i, (_, row) in enumerate(top10.iterrows(), 1):
            utd_flag = "✓" if row.get("Uptrend_Flag", False) else "·"
            tier_lbl = row.get("QG_Label", "T3")
            print(f"{enum_i:<4} {row['Ticker']:<10} {row['Sharpe']:>8.2f} {row['WinRate']:>7.1f}% "
                  f"{row['Prob_Up_%']:>7.1f}% {row['Score']:>7.3f} {row['Signal_Score']:>11.3f} "
                  f"{tier_lbl:>5} {utd_flag:>4} {row['Market_Regime']:<10}")

        # REKOMENDASI TOP 10
        print("\n" + "=" * 78)
        print("  🚀 REKOMENDASI TOP 10")
        print("=" * 78)

        top10_fundamental = []
        for idx, row in top10.iterrows():
            ticker = row["Ticker"]
            res = backtest_results.get(ticker, {})
            fc = forecast_results.get(ticker, {})
            fund = fundamental_data.get(ticker, {})

            last_price = row.get("Current_Price", res.get("last_price", 0))
            atr_val = res.get("atr")
            rsi_val = res.get("rsi")

            entry_price = last_price

            if atr_val and atr_val > 0:
                stop_loss = entry_price - (2 * atr_val)
                take_profit = entry_price + (6 * atr_val)
                rr_ratio = "1:3"
            else:
                stop_loss = entry_price * 0.95
                take_profit = entry_price * 1.10
                rr_ratio = "1:3 (default)"

            signal = row.get("Signal_MC", row.get("MC_Decision", "BUY"))

            pe_val = fund.get("trailingPE")
            pbv_val = fund.get("priceToBook")
            growth_val = fund.get("earningsGrowth")

            pe_str = f"{pe_val:.1f}" if pe_val is not None and not pd.isna(pe_val) else "N/A"
            pbv_str = f"{pbv_val:.2f}" if pbv_val is not None and not pd.isna(pbv_val) else "N/A"
            growth_str = f"{growth_val*100:.1f}%" if growth_val is not None and not pd.isna(growth_val) else "N/A"
            rsi_str = f"{rsi_val:.1f}" if rsi_val is not None and not pd.isna(rsi_val) else "N/A"
            
            avg_holding = row.get("Avg_Holding_Days", 0)
            regime = row.get("Market_Regime", "NORMAL")
            signal_score = row.get("Signal_Score", 0)

            top10_fundamental.append({
                "No": idx + 1, "Ticker": ticker, "Signal": signal, "Close": entry_price,
                "Stop Loss": stop_loss, "Take Profit": take_profit, "RR": rr_ratio,
                "RSI": rsi_str, "PE": pe_str, "PBV": pbv_str, "Vol_Source": fc.get("vol_source", "N/A"),
                "Earnings_Growth": growth_str, "P_SL_%": row.get("P_SL_%", 0), "EV_Rp": row.get("EV_Rp", 0),
                "Trend_Strength": row.get("Trend_Strength", 0), "Signal_Score": signal_score,
                "Market_Regime": regime, "Avg_Holding_Days": avg_holding,
            })

        df_rekomendasi = pd.DataFrame(top10_fundamental)

        if not df_rekomendasi.empty:
            print("\n📋 TABEL REKOMENDASI LENGKAP (TOP 10):")
            print("=" * 200)
            print(f"{'No':<4} {'Ticker':<10} {'Signal':<14} {'Close':>10} {'Stop Loss':>12} "
                  f"{'Take Profit':>13} {'RR':<8} {'RSI':<8} {'SignalScore':>10} {'Regime':<10} {'Avg_Hold':>10}")
            print("-" * 200)

            for _, row in df_rekomendasi.iterrows():
                close_val = f"{row['Close']:,.0f}" if isinstance(row['Close'], (int, float)) else str(row['Close'])
                sl_val = f"{row['Stop Loss']:,.0f}" if isinstance(row['Stop Loss'], (int, float)) else str(row['Stop Loss'])
                tp_val = f"{row['Take Profit']:,.0f}" if isinstance(row['Take Profit'], (int, float)) else str(row['Take Profit'])
                hold_val = f"{row['Avg_Holding_Days']:.1f}" if isinstance(row['Avg_Holding_Days'], (int, float)) else str(row['Avg_Holding_Days'])
                
                print(f"{row['No']:<4} {row['Ticker']:<10} {row['Signal']:<14} {close_val:>10} {sl_val:>12} "
                      f"{tp_val:>13} {row['RR']:<8} {row['RSI']:<8} {row['Signal_Score']:>10.3f} {row['Market_Regime']:<10} {hold_val:>10}")
            print("=" * 200)

            # Export ke CSV
            print("\n" + "=" * 78)
            print("  💾 MENYIMPAN REKOMENDASI KE FILE CSV")
            print("=" * 78)

            try:
                filename = f"aladdin_rekomendasi_hybrid_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                df_rekomendasi.to_csv(filename, index=False)
                print(f"   ✅ Rekomendasi disimpan ke: {filename}")

                filename2 = f"aladdin_ranking_hybrid_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                top10.to_csv(filename2, index=False)
                print(f"   ✅ Ranking TOP 10 disimpan ke: {filename2}")
            except Exception as e:
                print(f"   ⚠️ Gagal menyimpan CSV: {e}")

            # Ringkasan Eksekutif
            print("\n" + "=" * 78)
            print("  📋 RINGKASAN EKSEKUTIF (Hybrid 37.1.5 + Monte Carlo Gatekeeper)")
            print("=" * 78)

            avg_prob_up = top10["Prob_Up_%"].mean()
            avg_sharpe = top10["Sharpe"].mean()
            avg_winrate = top10["WinRate"].mean()
            avg_signal_score = top10["Signal_Score"].mean() if "Signal_Score" in top10.columns else 0
            avg_holding = top10["Avg_Holding_Days"].mean() if "Avg_Holding_Days" in top10.columns else 0
            garch_count = sum(1 for t in top10["Ticker"] if forecast_results.get(t, {}).get("garch_used", False))
            strong_buy_count = sum(top10["MC_Decision"] == "STRONG BUY")
            
            regime_counts = top10["Market_Regime"].value_counts().to_dict()
            regime_str = " | ".join([f"{k}:{v}" for k, v in regime_counts.items()])

            print(f"""
   📊 TOP 10 STATISTICS (HYBRID v37.1.5):
   ┌─────────────────────────────────────────────────────────────┐
   │  Rata-rata Probabilitas Up     : {avg_prob_up:.1f}%
   │  Rata-rata Sharpe Ratio        : {avg_sharpe:.2f}
   │  Rata-rata Win Rate            : {avg_winrate:.1f}%
   │  Rata-rata Signal Score        : {avg_signal_score:.3f}
   │  Rata-rata Holding Days        : {avg_holding:.1f} hari
   │  Saham dengan GARCH Volatility : {garch_count}/{len(top10)}
   │  STRONG BUY dari MC            : {strong_buy_count} saham
   │  Distribusi Market Regime      : {regime_str}
   └─────────────────────────────────────────────────────────────┘

   🎯 BEST PICK: {top10.iloc[0]['Ticker']}
      - Score          : {top10.iloc[0]['Score']:.3f}
      - Prob. Up       : {top10.iloc[0]['Prob_Up_%']:.1f}%
      - Signal Score   : {top10.iloc[0]['Signal_Score']:.3f}
      - MC Decision    : {top10.iloc[0]['MC_Decision']}
      - Market Regime  : {top10.iloc[0]['Market_Regime']}
""")

else:
    print("\n" + "=" * 78)
    print("  ⚠️ TIDAK ADA SAHAM YANG LOLOS SELEKSI")
    print("=" * 78)
    print("  Tidak ada saham untuk di-forecast dan diranking.\n")

# =============================================================
# DISCLAIMER
# =============================================================
print("\n" + "=" * 78)
print("  📋 DISCLAIMER & CATATAN (Rev 37.4.0 - FULL INTRADAY UPGRADE)")
print("=" * 78)
print(f"""
   ⚠️ INI BUKAN REKOMENDASI INVESTASI.
   Lakukan due diligence sendiri sebelum bertransaksi.
   
   PERBAIKAN SESI 1 (Rev -2):
   1. ✅ Import heavy packages setelah install_package selesai (BUG 1)
   2. ✅ macro_ok menggunakan USE_MACRO_FILTER & oil_change_5d (BUG 2)
   3. ✅ Hapus double-shift di Trend_Strength & RSI_Norm (BUG 3/5)
   4. ✅ df.copy() di awal run_backtest_intraday (BUG 8)
   5. ✅ split_timeframes return .copy() bukan view (BUG 9)
   6. ✅ trend_strength & avg_holding_days tersimpan ke backtest_results (BUG 10/11)
   7. ✅ MC Gatekeeper proses semua saham bukan 10 pertama saja (BUG 12)

   PERBAIKAN SESI 2 (Rev -3 / error log fix):
   8. ✅ KeyError 'score': kolom score dijamin ada sebelum print loop (BUG A/C)
   9. ✅ Hybrid Relax Mode bertahap 3 level, tidak crash saat fallback (BUG D)
  10. ✅ Hard filter diperlonggar: tier2 tanpa syarat trades, tambah tier3 (BUG B)
  11. ✅ mc_input_df dibangun atomik sekaligus — tidak ada partial assignment (BUG F)
  12. ✅ Banner EXIT_PROFIT_HOUR ditampilkan dalam format HH:MM yang benar (BUG E)

   FINE-TUNING Rev 37.2.0c (7 optimasi + 2 critical fix):
  [FT-1] ✅ COMPOSITE_WEIGHTS: low_vol 0.15→0.05, trend→0.30, momentum→0.25
  [FT-2] ✅ adaptive_weighting: 3M naik ke 0.60, 3Y turun ke 0.10 (intraday)
  [FT-3] ✅ Phase 4 Score: Signal_Score→0.22, N_Return→0.05, N_P_SL→0.15
  [FT-4] ✅ RSI Scoring: fungsi asimetris adaptif per regime (puncak di 70% range)
  [FT-5] ✅ Momentum: dinormalisasi terhadap vol_20*2 (range score realistis 0-1)
  [FT-6] ✅ Pump-and-Dump: threshold 250%, volume-spike sebagai konfirmasi combo
  [FT-7] ✅ get_dynamic_t_df: skewness negatif sebagai faktor penekan df

   CRITICAL FIX Rev 37.2.0c:
  [CF-1] ✅ P&D threshold 150%->250%: bukti empiris 53% saham terflag (seharusnya ~8%)
  [CF-2] ✅ MC mid_val: 0->median unrealized path (EV kini mencerminkan potensi nyata)

   PENINGKATAN AKURASI Rev 37.3.0 (Fase 1 + 3b):
  [1a]  ✅ MIN_SHARPE=-1.5: hard filter saham dengan backtest sangat buruk
  [1b]  ✅ MIN_WINRATE=25%: hard filter saham yang hampir selalu rugi historis
  [1d]  ✅ MIN_BACKTEST_TRADES=5: saham tanpa entry historis dibuang
  [3a]  ✅ price_open diaktifkan dari yfinance (dibutuhkan candle pattern)
  [3b]  ✅ Candle_Score ditambahkan ke composite signal (bobot 0.10)
        - Candle_Body_Pct, Candle_Dir, Candle_Strength sebagai variabel baru
        - Bullish candle kuat kemarin = sinyal lanjutan naik besok

   PATCH Rev 37.4.1:
  [P1]  ✅ MIN_BACKTEST_TRADES: 5→3 (IDX1 quality gate terlalu ketat, trades=3 masih valid)
  [P3]  ✅ P&D threshold: 250%→300% (IDX2: 38% saham terflag — harusnya hanya ~17-22%)
  [MC]  ✅ N_SIMULATIONS: 1000→2500 (SE zona borderline turun dari ±2.2% ke ±1.4%)
  [2c]  ✅ USD/IDR (IDR=X): macro variable baru
        - idr_regime: WEAK/STABLE/STRONG berdasarkan perubahan 5 hari
        - idr_pressure: True jika Rupiah melemah >3% → threshold sinyal +0.05
        - Jika USE_MACRO_FILTER=True: IDR pressure → macro_ok = False

   FULL IDX UNIVERSE: {len(idx_tickers)} saham
   BERHASIL DI-PROCESS: {processed_count} saham
""")

print(f"\n✅ Selesai! {datetime.now().strftime('%d %B %Y %H:%M:%S')}")
_exit_hm = f"{int(INTRADAY_EXIT_HOUR)}:{int((INTRADAY_EXIT_HOUR % 1)*60):02d}"
mode_str = f"INTRADAY (MAX_HOLDING={MAX_HOLDING_DAYS} hari, EXIT_HOUR={_exit_hm})" if INTRADAY_MODE else "SWING"
print(f"   Mode : {mode_str}")
print(f"   Backtest Version: HYBRID v37.5.2 (SHARPE-FIX: TC+ATR+THRESHOLD)")
print(f"   Adaptive Regime: {'AKTIF' if USE_ADAPTIVE_REGIME else 'NON-AKTIF'} (5 regime)")
print(f"   Composite Signal Score: AKTIF")
print(f"   Hybrid Selection Logic: AKTIF (3-level relax)")
print(f"   Monte Carlo Gatekeeper: AKTIF (Student-t df={DF_STUDENT}, N={N_SIMULATIONS}) [FT-7: skew-adjusted]")
print("=" * 78)